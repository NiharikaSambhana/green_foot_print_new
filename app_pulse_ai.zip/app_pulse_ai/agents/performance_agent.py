from config import CPU_THRESHOLD
from config import MEMORY_THRESHOLD
from config import LATENCY_THRESHOLD


class PerformanceAgent:

    def analyze(self, df):

        insights = []

        if "CPU %" in df.columns:

            max_cpu = df["CPU %"].max()

            if max_cpu > CPU_THRESHOLD:
                insights.append(
                    f"High CPU usage detected: {max_cpu}%"
                )

        if "Memory %" in df.columns:

            max_memory = df["Memory %"].max()

            if max_memory > MEMORY_THRESHOLD:
                insights.append(
                    f"High memory usage detected: {max_memory}%"
                )

        if "API Latency" in df.columns:

            max_latency = df["API Latency"].max()

            if max_latency > LATENCY_THRESHOLD:
                insights.append(
                    f"High API latency detected: {max_latency} ms"
                )

        return insights