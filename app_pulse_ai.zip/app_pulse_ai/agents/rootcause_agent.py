class RootCauseAgent:

    def analyze(self, df):

        root_causes = []

        if "Event" not in df.columns:
            return root_causes

        deployment_rows = df[
            df["Event"]
            .astype(str)
            .str.contains(
                "deploy",
                case=False,
                na=False
            )
        ]

        if not deployment_rows.empty:

            root_causes.append(
                "Performance issue may be related to deployment activity."
            )

        restart_rows = df[
            df["Event"]
            .astype(str)
            .str.contains(
                "restart",
                case=False,
                na=False
            )
        ]

        if not restart_rows.empty:

            root_causes.append(
                "Application restarts detected."
            )

        return root_causes