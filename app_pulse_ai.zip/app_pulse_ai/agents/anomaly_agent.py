from sklearn.ensemble import IsolationForest
import pandas as pd

from config import ANOMALY_CONTAMINATION


class AnomalyAgent:

    def detect(self, df):

        numeric_df = df.select_dtypes(include=["number"])

        if numeric_df.empty:
            return pd.DataFrame()

        model = IsolationForest(
            contamination=ANOMALY_CONTAMINATION,
            random_state=42
        )

        predictions = model.fit_predict(numeric_df)

        df["Anomaly"] = predictions

        anomalies = df[df["Anomaly"] == -1]

        return anomalies