class RecommendationAgent:

    def recommend(self, df):

        recommendations = []

        if "CPU %" in df.columns:

            if df["CPU %"].max() > 85:

                recommendations.append(
                    "Increase CPU allocation or scale pods horizontally."
                )

        if "Memory %" in df.columns:

            if df["Memory %"].max() > 90:

                recommendations.append(
                    "Investigate possible memory leaks."
                )

        if "API Latency" in df.columns:

            if df["API Latency"].max() > 500:

                recommendations.append(
                    "Optimize slow APIs and database queries."
                )

        return recommendations