import streamlit as st
import pandas as pd
import plotly.express as px

from utils.preprocessing import clean_dataframe
from utils.preprocessing import convert_numeric_columns

from guardrails.validations import validate_dataframe
from guardrails.security_guard import is_safe_prompt

from rag.ingest import create_vector_store
from rag.retriever import get_retriever

from agents.performance_agent import PerformanceAgent
from agents.anomaly_agent import AnomalyAgent
from agents.rootcause_agent import RootCauseAgent
from agents.recommendation_agent import RecommendationAgent

st.set_page_config(
    page_title="APP Pulse AI",
    layout="wide"
)

st.title("🚀 APP Pulse AI")

uploaded_file = st.file_uploader(
    "Upload ODS File",
    type=["ods"]
)


@st.cache_data
def load_data(file):

    df = pd.read_excel(
        file,
        engine="odf"
    )

    return df


if uploaded_file:

    df = load_data(uploaded_file)

    df = clean_dataframe(df)

    df = convert_numeric_columns(df)

    missing_cols = validate_dataframe(df)

    if missing_cols:

        st.error(
            f"Missing required columns: {missing_cols}"
        )

        st.stop()

    st.success("File loaded successfully!")

    st.write("## 📊 Uploaded Data")

    st.dataframe(
        df,
        use_container_width=True
    )

    # -----------------------------
    # CREATE VECTOR STORE
    # -----------------------------

    create_vector_store(df)

    # -----------------------------
    # AGENTS
    # -----------------------------

    performance_agent = PerformanceAgent()

    anomaly_agent = AnomalyAgent()

    rootcause_agent = RootCauseAgent()

    recommendation_agent = RecommendationAgent()

    performance_results = performance_agent.analyze(df)

    anomaly_results = anomaly_agent.detect(df)

    rootcause_results = rootcause_agent.analyze(df)

    recommendation_results = recommendation_agent.recommend(df)

    # -----------------------------
    # DISPLAY AI INSIGHTS
    # -----------------------------

    st.write("## 🧠 AI Insights")

    for result in performance_results:
        st.warning(result)

    for result in rootcause_results:
        st.error(result)

    for result in recommendation_results:
        st.info(result)

    # -----------------------------
    # ANOMALIES
    # -----------------------------

    st.write("## 🚨 Detected Anomalies")

    if not anomaly_results.empty:

        st.dataframe(
            anomaly_results,
            use_container_width=True
        )

    else:
        st.success("No anomalies detected.")

    # -----------------------------
    # CHARTS
    # -----------------------------

    st.write("## 📈 Metrics Over Time")

    if "Time" in df.columns:

        df["Time"] = df["Time"].astype(str)

        metrics = [
            col for col in df.columns
            if col not in ["Time", "Event"]
        ]

        for i in range(0, len(metrics), 2):

            col1, col2 = st.columns(2)

            with col1:

                metric = metrics[i]

                fig = px.line(
                    df,
                    x="Time",
                    y=metric,
                    title=f"{metric} over Time"
                )

                st.plotly_chart(
                    fig,
                    use_container_width=True
                )

            if i + 1 < len(metrics):

                with col2:

                    metric = metrics[i + 1]

                    fig = px.line(
                        df,
                        x="Time",
                        y=metric,
                        title=f"{metric} over Time"
                    )

                    st.plotly_chart(
                        fig,
                        use_container_width=True
                    )

    # -----------------------------
    # RAG CHATBOT
    # -----------------------------

    st.write("## 🤖 Ask APP Pulse AI")

    query = st.text_input(
        "Ask about performance metrics"
    )

    if query:

        if not is_safe_prompt(query):

            st.error(
                "Unsafe query detected."
            )

            st.stop()

        retriever = get_retriever()

        docs = retriever.get_relevant_documents(
            query
        )

        st.write("### Retrieved Context")

        for doc in docs:

            st.write(doc.page_content)