import pandas as pd


def clean_dataframe(df):

    df.columns = [
        col.strip()
        for col in df.columns
    ]

    df = df.drop_duplicates()

    return df


def convert_numeric_columns(df):

    for col in df.columns:

        try:
            df[col] = pd.to_numeric(df[col])
        except:
            pass

    return df