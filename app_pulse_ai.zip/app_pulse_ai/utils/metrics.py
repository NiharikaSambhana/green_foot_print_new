def calculate_summary(df):

    summary = {}

    numeric_cols = df.select_dtypes(
        include=["number"]
    ).columns

    for col in numeric_cols:

        summary[col] = {
            "mean": df[col].mean(),
            "max": df[col].max(),
            "min": df[col].min()
        }

    return summary