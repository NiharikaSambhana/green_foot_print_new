import os

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma

from rag.embeddings import load_embeddings
from config import VECTOR_DB_DIR


def dataframe_to_documents(df):

    documents = []

    for _, row in df.iterrows():

        row_text = " | ".join(
            [f"{col}: {row[col]}" for col in df.columns]
        )

        documents.append(row_text)

    return documents


def create_vector_store(df):

    documents = dataframe_to_documents(df)

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=50
    )

    chunks = splitter.create_documents(documents)

    embeddings = load_embeddings()

    if not os.path.exists(VECTOR_DB_DIR):
        os.makedirs(VECTOR_DB_DIR)

    vectordb = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=VECTOR_DB_DIR
    )

    return vectordb