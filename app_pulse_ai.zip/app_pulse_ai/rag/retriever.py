from langchain_community.vectorstores import Chroma

from rag.embeddings import load_embeddings
from config import VECTOR_DB_DIR


def get_retriever():

    embeddings = load_embeddings()

    vectordb = Chroma(
        persist_directory=VECTOR_DB_DIR,
        embedding_function=embeddings
    )

    retriever = vectordb.as_retriever(
        search_kwargs={"k": 5}
    )

    return retriever