from langchain_community.embeddings import HuggingFaceEmbeddings
from config import EMBEDDING_MODEL


def load_embeddings():

    embeddings = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL
    )

    return embeddings