BLOCKED_PATTERNS = [
    "ignore previous instructions",
    "delete database",
    "shutdown system",
    "hack",
    "bypass security"
]


def is_safe_prompt(prompt):

    prompt = prompt.lower()

    for pattern in BLOCKED_PATTERNS:

        if pattern in prompt:
            return False

    return True