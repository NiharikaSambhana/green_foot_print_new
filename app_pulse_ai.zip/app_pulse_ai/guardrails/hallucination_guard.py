def validate_response(response, retrieved_docs):

    context = " ".join(
        [doc.page_content for doc in retrieved_docs]
    )

    response_words = response.lower().split()

    matched = 0

    for word in response_words:

        if word in context.lower():
            matched += 1

    score = matched / max(len(response_words), 1)

    if score < 0.2:

        return (
            False,
            "Response may not be grounded in retrieved data."
        )

    return True, response