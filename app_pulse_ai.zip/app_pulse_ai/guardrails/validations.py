REQUIRED_COLUMNS = [
    "Time"
]


def validate_dataframe(df):

    missing_columns = []

    for col in REQUIRED_COLUMNS:

        if col not in df.columns:
            missing_columns.append(col)

    return missing_columns