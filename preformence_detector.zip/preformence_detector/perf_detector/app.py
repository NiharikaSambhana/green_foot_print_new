# ============================================================
# app.py — PerfGuard AI  |  Main Streamlit Entry Point
# ============================================================

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import streamlit as st

st.set_page_config(
    page_title="PerfGuard AI",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---- Global CSS -----------------------------------------------
st.markdown("""
<style>
/* Base */
[data-testid="stAppViewContainer"] { background: #0d1117; }
[data-testid="stSidebar"]          { background: #161b22; border-right: 1px solid #30363d; }
section.main .block-container      { padding-top: 1.5rem; }

/* Typography */
h1 { color: #58a6ff !important; font-weight: 800 !important; }
h2 { color: #79c0ff !important; }
h3 { color: #a5d6ff !important; }
p, li, label { color: #c9d1d9 !important; }

/* Cards */
.pg-card {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 12px;
    padding: 1.2rem 1.5rem;
    margin-bottom: 1rem;
}
.pg-card-green  { border-left: 4px solid #3fb950; }
.pg-card-red    { border-left: 4px solid #f85149; }
.pg-card-yellow { border-left: 4px solid #d29922; }
.pg-card-blue   { border-left: 4px solid #58a6ff; }

/* Metric badges */
.sev-critical { background:#f85149;color:#fff;padding:2px 10px;border-radius:20px;font-size:0.75rem;font-weight:700; }
.sev-high     { background:#d29922;color:#000;padding:2px 10px;border-radius:20px;font-size:0.75rem;font-weight:700; }
.sev-medium   { background:#388bfd;color:#fff;padding:2px 10px;border-radius:20px;font-size:0.75rem;font-weight:700; }
.sev-low      { background:#3fb950;color:#000;padding:2px 10px;border-radius:20px;font-size:0.75rem;font-weight:700; }

/* Confidence ring */
.conf-high   { color: #3fb950; font-weight: 700; }
.conf-medium { color: #d29922; font-weight: 700; }
.conf-low    { color: #f85149; font-weight: 700; }

/* Input */
[data-testid="stTextArea"] textarea,
[data-testid="stTextInput"] input {
    background: #0d1117 !important;
    border: 1px solid #30363d !important;
    color: #c9d1d9 !important;
    border-radius: 8px !important;
}

/* Buttons */
.stButton > button {
    background: linear-gradient(135deg, #1f6feb, #388bfd) !important;
    color: #fff !important;
    border: none !important;
    border-radius: 8px !important;
    font-weight: 600 !important;
    padding: 0.5rem 1.5rem !important;
    transition: transform 0.1s;
}
.stButton > button:hover { transform: scale(1.03); }

/* Tabs */
[data-testid="stHorizontalBlock"] { gap: 0.5rem; }
button[data-baseweb="tab"]         { color: #79c0ff !important; }
button[data-baseweb="tab"][aria-selected="true"] {
    border-bottom: 2px solid #58a6ff !important;
}

/* Sidebar items */
.sidebar-item {
    padding: 0.6rem 0.8rem;
    border-radius: 8px;
    cursor: pointer;
    margin-bottom: 0.3rem;
    color: #c9d1d9;
    transition: background 0.2s;
}
.sidebar-item:hover, .sidebar-item.active {
    background: #21262d;
    color: #58a6ff;
}

/* Scrollbar */
::-webkit-scrollbar       { width: 6px; }
::-webkit-scrollbar-track { background: #0d1117; }
::-webkit-scrollbar-thumb { background: #30363d; border-radius: 3px; }
</style>
""", unsafe_allow_html=True)


# ---- Sidebar Navigation ---------------------------------------
with st.sidebar:
    st.markdown("""
    <div style='text-align:center; padding: 1rem 0 1.5rem;'>
        <div style='font-size:2.5rem;'>🛡️</div>
        <div style='font-size:1.3rem; font-weight:800; color:#58a6ff;'>PerfGuard AI</div>
        <div style='font-size:0.75rem; color:#8b949e; margin-top:4px;'>
            Performance Regression Detector
        </div>
    </div>
    <hr style='border-color:#30363d; margin:0 0 1rem;'>
    """, unsafe_allow_html=True)

    pages = {
        "🏠  Home":              "home",
        "📤  Upload & Ingest":   "ingest",
        "🔍  Analyze & Detect":  "analyze",
        "🤖  AI Assistant":      "chat",
        "📊  Dashboard":         "dashboard",
        "🧪  Simulation":        "simulation",
        "📈  Evaluation":        "evaluation",
        "ℹ️   About":             "about",
    }

    if "page" not in st.session_state:
        st.session_state.page = "home"

    for label, key in pages.items():
        active = "active" if st.session_state.page == key else ""
        if st.button(label, key=f"nav_{key}",
                     use_container_width=True):
            st.session_state.page = key
            st.rerun()

    st.markdown("<hr style='border-color:#30363d;'>", unsafe_allow_html=True)
    st.markdown("""
    <div style='font-size:0.7rem; color:#484f58; text-align:center; padding:0.5rem;'>
        Powered by LangGraph + DeepSeek<br>TCS GenAI Lab Platform
    </div>
    """, unsafe_allow_html=True)


# ---- Route to page --------------------------------------------
page = st.session_state.page

if page == "home":
    from frontend.pages import home; home.render()
elif page == "ingest":
    from frontend.pages import ingest; ingest.render()
elif page == "analyze":
    from frontend.pages import analyze; analyze.render()
elif page == "chat":
    from frontend.pages import chat; chat.render()
elif page == "dashboard":
    from frontend.pages import dashboard; dashboard.render()
elif page == "simulation":
    from frontend.pages import simulation; simulation.render()
elif page == "evaluation":
    from frontend.pages import evaluation; evaluation.render()
elif page == "about":
    from frontend.pages import about; about.render()
