# 🛡️ PerfGuard AI
### AI-Based Application Performance Regression Detector with Root Cause Insights

---

## 🚀 Quick Start (Hackathon Setup)

```bash
# 1. Clone / open in VS Code
cd perf_detector

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set your API key
cp .env.example .env
# Edit .env → set API_KEY=your_key_here

# 4. Generate sample data (for demo)
python -m backend.utils.synthetic_data

# 5. Run the app
streamlit run app.py
```

---

## 📁 File Structure

```
perf_detector/
│
├── app.py                          # Streamlit entry point
├── requirements.txt
├── .env.example                    # Copy → .env, add API key
│
├── backend/
│   ├── core/
│   │   ├── config.py               # All settings (edit per problem)
│   │   ├── llm_factory.py          # LLM + embedding factory
│   │   ├── http_client.py          # SSL patches (ONE place)
│   │   └── logger.py               # Structured JSON logging
│   │
│   ├── rag/
│   │   ├── document_loader.py      # PDF/CSV/JSON/Image/ODS loader
│   │   ├── data_cleaner.py         # Normalize + clean docs
│   │   ├── ingest.py               # Chunk → Embed → ChromaDB
│   │   └── retriever.py            # Semantic search + confidence
│   │
│   ├── agents/
│   │   └── graph.py                # LangGraph multi-agent system
│   │       # Supervisor → Detector → Root Cause → Optimizer → Reporter → RAG
│   │
│   ├── evaluation/
│   │   └── metrics.py              # ROUGE, grounding, faithfulness
│   │
│   └── utils/
│       └── synthetic_data.py       # Demo data generator
│
├── frontend/
│   └── pages/
│       ├── home.py                 # Landing page
│       ├── ingest.py               # File upload UI
│       ├── analyze.py              # Regression analysis UI
│       ├── chat.py                 # Conversational AI
│       ├── dashboard.py            # Metrics charts
│       ├── simulation.py           # Live demo simulation
│       ├── evaluation.py           # Quality metrics
│       └── about.py                # System info
│
├── data/                           # Your data files go here
├── vectordb/                       # ChromaDB persisted here
└── logs/                           # App logs
```

---

## 🤖 Multi-Agent Architecture

```
User Query
    ↓
[Supervisor Agent] ← LLM-based router
    ↓
    ├── [Detector Agent]    → Anomaly detection in CPU/Memory/Latency/Errors
    ├── [Root Cause Agent]  → Deep reasoning with DeepSeek-R1
    ├── [Optimizer Agent]   → Ranked remediation steps
    ├── [Reporter Agent]    → Formal incident report
    └── [RAG Agent]         → Knowledge base Q&A with citations
```

---

## 🔧 Adapting for a Different Problem Statement

| What to change | Where |
|---|---|
| App name / domain | `backend/core/config.py` → `APP_NAME`, `DOMAIN` |
| LLM model | `config.py` → `CHAT_MODEL` |
| Anomaly thresholds | `config.py` → `CPU_THRESHOLD`, etc. |
| Add new agent | `backend/agents/graph.py` → add new node function |
| Add file type support | `backend/rag/document_loader.py` → add to `LOADERS` |
| Change chunking | `config.py` → `CHUNK_SIZE`, `CHUNK_OVERLAP` |
| Add tools | `backend/agents/graph.py` → add tool function |
| Change UI pages | `frontend/pages/` → add/edit page files |

---

## 📊 Key Technologies

- **LangGraph** — Multi-agent orchestration with state machine
- **DeepSeek-V3** — Main LLM (fast, capable)
- **DeepSeek-R1** — Reasoning model for root cause analysis
- **Llama-3.2-90B Vision** — Multimodal (image/chart parsing)
- **ChromaDB** — Local vector database
- **text-embedding-3-large** — Semantic embeddings
- **Streamlit** — Interactive UI
- **Plotly** — Interactive charts

---

## 💡 Confidence Scoring

Confidence is computed two ways and blended:
1. **Embedding distance** → `(2 - L2_distance) / 2 * 100`
2. **LLM logprobs** → `exp(avg_logprob) * 100`

Final: `60% retrieval confidence + 40% LLM confidence`
