# ============================================================
# backend/core/http_client.py — SSL patches in ONE place
# ============================================================

import httpx, requests, urllib3, ssl, os, logging

logger = logging.getLogger(__name__)

def _patch_ssl():
    os.environ["TIKTOKEN_CACHE_DIR"] = "./tiktoken_cache"
    os.environ["PYTHONHTTPSVERIFY"] = "0"
    ssl._create_default_https_context = ssl._create_unverified_context
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    _orig = requests.get
    requests.get = lambda url, **kw: _orig(url, verify=False,
        **{k: v for k, v in kw.items() if k != "verify"})

_patch_ssl()
sync_client  = httpx.Client(verify=False, timeout=60.0)
async_client = httpx.AsyncClient(verify=False, timeout=60.0)
