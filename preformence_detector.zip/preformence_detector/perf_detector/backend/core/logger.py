# ============================================================
# backend/core/logger.py
# ============================================================

import logging, logging.handlers, json, os
from datetime import datetime
from backend.core.config import settings


class JSONFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps({
            "ts": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "module": record.module,
            "msg": record.getMessage(),
            **({"exc": self.formatException(record.exc_info)} if record.exc_info else {})
        })


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    logger.setLevel(getattr(logging, settings.LOG_LEVEL, logging.INFO))

    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter("[%(levelname)s] %(name)s — %(message)s"))
    logger.addHandler(ch)

    os.makedirs("logs", exist_ok=True)
    fh = logging.handlers.RotatingFileHandler(
        "logs/app.log", maxBytes=10*1024*1024, backupCount=5)
    fh.setFormatter(JSONFormatter())
    logger.addHandler(fh)
    return logger
