# ============================================================
# backend/core/config.py
# ============================================================

import os
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

load_dotenv()


class Settings(BaseSettings):

    # App
    APP_NAME: str = "PerfGuard AI"
    APP_VERSION: str = "1.0.0"
    LOG_LEVEL: str = "INFO"

    # LLM
    BASE_URL: str = "https://genailab.tcs.in"
    API_KEY: str = "dummy"
    CHAT_MODEL: str = "azure_ai/genailab-maas-DeepSeek-V3-0324"
    REASONING_MODEL: str = "azure_ai/genailab-maas-DeepSeek-R1"
    EMBEDDING_MODEL: str = "azure/genailab-maas-text-embedding-3-large"
    VISION_MODEL: str = "azure_ai/genailab-maas-Llama-3.2-90B-Vision-Instruct"

    # Generation
    TEMPERATURE: float = 0.1
    MAX_TOKENS: int = 2048
    TOP_P: float = 0.9

    # RAG
    DATA_FOLDER: str = "data"
    VECTOR_DB_PATH: str = "vectordb/chroma_db"
    COLLECTION_NAME: str = "perfguard_docs"
    CHUNK_SIZE: int = 800
    CHUNK_OVERLAP: int = 150
    RETRIEVAL_K: int = 5
    SIMILARITY_THRESHOLD: float = 0.35

    # Agents
    MAX_ITERATIONS: int = 8
    AGENT_TIMEOUT: int = 90

    # Anomaly thresholds  ← 🔧 tune per problem
    CPU_THRESHOLD: float = 85.0       # % above = anomaly
    MEMORY_THRESHOLD: float = 90.0    # %
    LATENCY_THRESHOLD: float = 2000.0 # ms
    ERROR_RATE_THRESHOLD: float = 5.0 # %

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
