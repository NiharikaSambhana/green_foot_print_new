# ============================================================
# backend/core/llm_factory.py
# ============================================================

from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from backend.core.config import settings
from backend.core.http_client import sync_client, async_client


def get_llm(temperature: float = None, model: str = None, streaming: bool = False):
    return ChatOpenAI(
        base_url=settings.BASE_URL,
        model=model or settings.CHAT_MODEL,
        api_key=settings.API_KEY,
        temperature=temperature if temperature is not None else settings.TEMPERATURE,
        max_tokens=settings.MAX_TOKENS,
        http_client=sync_client,
        http_async_client=async_client,
        streaming=streaming,
        logprobs=True,          # ← enables confidence scoring
        top_logprobs=5,
    )


def get_reasoning_llm():
    """Use DeepSeek-R1 for complex root cause analysis."""
    return get_llm(model=settings.REASONING_MODEL, temperature=0.0)


def get_embedding_model():
    return OpenAIEmbeddings(
        base_url=settings.BASE_URL,
        model=settings.EMBEDDING_MODEL,
        api_key=settings.API_KEY,
        http_client=sync_client,
        http_async_client=async_client,
    )
