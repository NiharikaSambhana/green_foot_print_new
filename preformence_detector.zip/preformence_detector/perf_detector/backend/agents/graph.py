# ============================================================
# backend/agents/graph.py
# LangGraph Multi-Agent: Supervisor → 5 Specialized Agents
# ============================================================

import json, math
from typing import TypedDict, Literal, List, Annotated
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
import operator

from backend.core.config import settings
from backend.core.llm_factory import get_llm, get_reasoning_llm
from backend.core.logger import get_logger
from backend.rag.ingest import load_vector_db
from backend.rag.retriever import PerfRetriever, _logprob_confidence

logger = get_logger(__name__)


# ============================================================
# STATE
# ============================================================

class AgentState(TypedDict):
    messages:        List
    next:            str
    context:         str          # RAG context string
    metrics_data:    dict         # Parsed performance metrics
    anomalies:       List[dict]   # Detected anomalies
    root_causes:     List[str]    # RCA findings
    recommendations: List[str]    # Optimization suggestions
    report:          str          # Final generated report
    confidence:      float        # Answer confidence 0–100
    session_id:      str


# ============================================================
# LLM INSTANCES
# ============================================================

def _llm():
    return get_llm(temperature=0.1)

def _reasoning_llm():
    return get_reasoning_llm()


# ============================================================
# PROMPT ENGINEERING TEMPLATE
# Role / Context / Problem / Example / Expected Output
# ============================================================

def build_prompt(role: str, context: str, problem: str,
                 example: str = "", expected_output: str = "") -> str:
    return f"""## ROLE
{role}

## CONTEXT
{context}

## PROBLEM
{problem}

## EXAMPLE
{example if example else "N/A"}

## EXPECTED OUTPUT FORMAT
{expected_output if expected_output else "Provide a clear, structured response."}
"""


# ============================================================
# AGENT 1 — SUPERVISOR (Router)
# ============================================================

def supervisor(state: AgentState) -> AgentState:
    logger.info("Supervisor: routing query")
    llm = _llm()
    last = state["messages"][-1].content

    system = SystemMessage(content="""You are the Supervisor Agent for PerfGuard AI — 
an Application Performance Regression Detection system.

Route the user query to exactly ONE agent:
- detector     → detect anomalies / regressions in metrics or logs
- root_cause   → analyze WHY a regression happened (deep reasoning)
- optimizer    → suggest fixes and optimizations to resolve regressions
- reporter     → generate a formal regression report or summary
- rag_agent    → answer general questions using the knowledge base
- END          → completely off-topic, unrelated to performance/apps

Reply with ONLY the agent name. Nothing else.""")

    response = llm.invoke([system, HumanMessage(content=last)])
    decision = response.content.strip().lower()

    route_map = {
        "detector":   "detector",
        "root_cause": "root_cause",
        "optimizer":  "optimizer",
        "reporter":   "reporter",
        "rag_agent":  "rag_agent",
        "end":        END,
    }
    next_node = route_map.get(decision, "detector")
    logger.info(f"Supervisor routed to: {next_node}")
    return {**state, "next": next_node}


# ============================================================
# AGENT 2 — ANOMALY DETECTOR
# ============================================================

def detector_agent(state: AgentState) -> AgentState:
    logger.info("Detector Agent: analyzing metrics")
    llm = _llm()
    last = state["messages"][-1].content
    metrics = state.get("metrics_data", {})

    # Pull RAG context
    try:
        vdb = load_vector_db()
        retriever = PerfRetriever(vdb)
        context = retriever.get_context(last, k=4)
    except Exception:
        context = "No historical data available."

    prompt = build_prompt(
        role="You are an expert Application Performance Anomaly Detector. "
             "You analyze CPU, memory, latency, error rates and identify regressions.",
        context=f"Historical context:\n{context}\n\nCurrent metrics:\n{json.dumps(metrics, indent=2)}",
        problem=f"User query: {last}\n\n"
                f"Thresholds — CPU>{settings.CPU_THRESHOLD}%, "
                f"Memory>{settings.MEMORY_THRESHOLD}%, "
                f"Latency>{settings.LATENCY_THRESHOLD}ms, "
                f"Error Rate>{settings.ERROR_RATE_THRESHOLD}%",
        example="CPU spikes from 40% to 92% at 14:30 UTC → REGRESSION DETECTED",
        expected_output="""List anomalies as JSON array:
[{"metric": "CPU", "value": 92, "threshold": 85, "severity": "HIGH", 
  "timestamp": "14:30 UTC", "description": "CPU spike 40%→92%"}]
Then provide a brief natural language summary."""
    )

    resp = llm.invoke([HumanMessage(content=prompt)])
    content = resp.content

    # Parse anomalies from response
    anomalies = []
    try:
        start = content.find("[")
        end   = content.rfind("]") + 1
        if start >= 0 and end > start:
            anomalies = json.loads(content[start:end])
    except Exception:
        pass

    # Confidence from logprobs
    conf = _logprob_confidence(resp) or 78.0

    updated_messages = state["messages"] + [AIMessage(content=content)]
    return {**state,
            "messages":   updated_messages,
            "context":    context,
            "anomalies":  anomalies,
            "confidence": conf,
            "next":       "supervisor"}


# ============================================================
# AGENT 3 — ROOT CAUSE ANALYZER (uses DeepSeek-R1 reasoning)
# ============================================================

def root_cause_agent(state: AgentState) -> AgentState:
    logger.info("Root Cause Agent: deep analysis with reasoning model")
    llm = _reasoning_llm()
    last = state["messages"][-1].content
    anomalies = state.get("anomalies", [])

    try:
        vdb = load_vector_db()
        retriever = PerfRetriever(vdb)
        context = retriever.get_context(
            f"root cause regression {last}", k=5)
    except Exception:
        context = "No historical context."

    prompt = build_prompt(
        role="You are a Senior Site Reliability Engineer specializing in root cause analysis. "
             "You use systematic elimination to identify WHY performance regressions occur.",
        context=f"Detected anomalies:\n{json.dumps(anomalies, indent=2)}\n\n"
                f"Historical incidents:\n{context}",
        problem=f"Query: {last}\n\nPerform root cause analysis.",
        example="Pattern: CPU spike correlates with deployment at 14:25 UTC → "
                "Root Cause: Memory leak in v2.3.1 — inefficient DB connection pooling",
        expected_output="""Provide:
1. ROOT CAUSE (primary): [concise statement]
2. CONTRIBUTING FACTORS: [list]
3. EVIDENCE: [what data supports this]
4. CONFIDENCE: [percentage with reasoning]
5. INCIDENT TIMELINE: [sequence of events]"""
    )

    resp = llm.invoke([HumanMessage(content=prompt)])
    content = resp.content
    conf = _logprob_confidence(resp) or 72.0

    root_causes = [content]
    updated_messages = state["messages"] + [AIMessage(content=content)]
    return {**state,
            "messages":   updated_messages,
            "root_causes": root_causes,
            "confidence": conf,
            "next":       "supervisor"}


# ============================================================
# AGENT 4 — OPTIMIZER
# ============================================================

def optimizer_agent(state: AgentState) -> AgentState:
    logger.info("Optimizer Agent: generating recommendations")
    llm = _llm()
    last = state["messages"][-1].content
    anomalies   = state.get("anomalies", [])
    root_causes = state.get("root_causes", [])

    try:
        vdb = load_vector_db()
        retriever = PerfRetriever(vdb)
        context = retriever.get_context(f"fix optimize {last}", k=4)
    except Exception:
        context = ""

    prompt = build_prompt(
        role="You are a Performance Optimization Expert. "
             "You provide actionable remediation steps ranked by impact and ease of implementation.",
        context=f"Root causes:\n{chr(10).join(root_causes)}\n\n"
                f"Anomalies:\n{json.dumps(anomalies, indent=2)}\n\n"
                f"Best practices from KB:\n{context}",
        problem=f"Generate optimization recommendations for: {last}",
        example="If CPU>85%: Scale horizontally, optimize hot-path queries, enable caching",
        expected_output="""Provide recommendations as:
IMMEDIATE (< 1 hour): [actions]
SHORT-TERM (< 1 day): [actions]  
LONG-TERM (< 1 week): [actions]
ESTIMATED IMPACT: [% improvement expected]"""
    )

    resp = llm.invoke([HumanMessage(content=prompt)])
    content = resp.content
    conf = _logprob_confidence(resp) or 75.0

    recs = [line.strip() for line in content.split("\n")
            if line.strip() and not line.startswith("#")]

    updated_messages = state["messages"] + [AIMessage(content=content)]
    return {**state,
            "messages":        updated_messages,
            "recommendations": recs,
            "confidence":      conf,
            "next":            "supervisor"}


# ============================================================
# AGENT 5 — REPORTER
# ============================================================

def reporter_agent(state: AgentState) -> AgentState:
    logger.info("Reporter Agent: generating formal report")
    llm = _llm()
    last        = state["messages"][-1].content
    anomalies   = state.get("anomalies", [])
    root_causes = state.get("root_causes", [])
    recs        = state.get("recommendations", [])

    prompt = build_prompt(
        role="You are a Technical Report Writer for enterprise SRE teams. "
             "You produce clear, structured regression reports for executives and engineers.",
        context=f"Anomalies: {json.dumps(anomalies, indent=2)}\n"
                f"Root Causes: {chr(10).join(root_causes)}\n"
                f"Recommendations: {chr(10).join(recs[:5])}",
        problem=f"Generate a formal performance regression report for: {last}",
        example="Incident INC-2024-001: CPU regression detected at 14:30 UTC affecting checkout service",
        expected_output="""
# Performance Regression Report
## Executive Summary
## Incident Details (timestamp, severity, affected services)
## Detected Anomalies
## Root Cause Analysis
## Impact Assessment
## Recommendations
## Prevention Measures
## Appendix (raw metrics)
"""
    )

    resp = llm.invoke([HumanMessage(content=prompt)])
    content = resp.content
    conf = _logprob_confidence(resp) or 80.0

    updated_messages = state["messages"] + [AIMessage(content=content)]
    return {**state,
            "messages":   updated_messages,
            "report":     content,
            "confidence": conf,
            "next":       "supervisor"}


# ============================================================
# AGENT 6 — RAG Q&A AGENT
# ============================================================

def rag_agent(state: AgentState) -> AgentState:
    logger.info("RAG Agent: knowledge base Q&A")
    llm = _llm()
    last = state["messages"][-1].content

    try:
        vdb = load_vector_db()
        retriever = PerfRetriever(vdb)
        context = retriever.get_context(last, k=5)
        chunks  = retriever.retrieve(last, k=5)
        conf_scores = [c["confidence"] for c in chunks]
        retrieval_conf = round(sum(conf_scores)/len(conf_scores), 2) if conf_scores else 50.0
    except Exception as e:
        context = "Knowledge base unavailable."
        retrieval_conf = 0.0

    prompt = build_prompt(
        role="You are a Performance Engineering Knowledge Assistant. "
             "Answer questions using ONLY the provided context. Cite sources.",
        context=context,
        problem=last,
        expected_output="Answer with source citations. If context is insufficient, say so clearly."
    )

    resp = llm.invoke([HumanMessage(content=prompt)])
    content = resp.content
    llm_conf = _logprob_confidence(resp)
    # Blend retrieval confidence + LLM confidence
    final_conf = round((retrieval_conf * 0.6 + llm_conf * 0.4), 2) if llm_conf else retrieval_conf

    updated_messages = state["messages"] + [AIMessage(content=content)]
    return {**state,
            "messages":   updated_messages,
            "context":    context,
            "confidence": final_conf,
            "next":       "supervisor"}


# ============================================================
# BUILD LANGGRAPH
# ============================================================

def build_graph():
    workflow = StateGraph(AgentState)

    workflow.add_node("supervisor", supervisor)
    workflow.add_node("detector",   detector_agent)
    workflow.add_node("root_cause", root_cause_agent)
    workflow.add_node("optimizer",  optimizer_agent)
    workflow.add_node("reporter",   reporter_agent)
    workflow.add_node("rag_agent",  rag_agent)

    workflow.set_entry_point("supervisor")

    # Supervisor routes dynamically
    workflow.add_conditional_edges(
        "supervisor",
        lambda x: x["next"],
        {
            "detector":   "detector",
            "root_cause": "root_cause",
            "optimizer":  "optimizer",
            "reporter":   "reporter",
            "rag_agent":  "rag_agent",
            END:          END,
        }
    )

    # All agents return to supervisor (allows multi-hop)
    for node in ["detector", "root_cause", "optimizer", "reporter", "rag_agent"]:
        workflow.add_edge(node, END)   # Single-hop for speed; change to "supervisor" for chaining

    return workflow.compile()


# Compiled graph singleton
graph = build_graph()


# ============================================================
# PUBLIC INTERFACE
# ============================================================

def run_query(
    query: str,
    metrics_data: dict = None,
    session_id: str = "default",
) -> dict:
    """Run query through the multi-agent graph."""
    initial_state: AgentState = {
        "messages":        [HumanMessage(content=query)],
        "next":            "",
        "context":         "",
        "metrics_data":    metrics_data or {},
        "anomalies":       [],
        "root_causes":     [],
        "recommendations": [],
        "report":          "",
        "confidence":      0.0,
        "session_id":      session_id,
    }

    try:
        result = graph.invoke(initial_state)
        last_msg = result["messages"][-1].content if result["messages"] else "No response"
        return {
            "answer":          last_msg,
            "anomalies":       result.get("anomalies", []),
            "root_causes":     result.get("root_causes", []),
            "recommendations": result.get("recommendations", []),
            "report":          result.get("report", ""),
            "confidence":      result.get("confidence", 0.0),
            "status":          "success",
        }
    except Exception as e:
        logger.error(f"Graph execution failed: {e}")
        return {
            "answer":    f"System error: {str(e)}",
            "anomalies": [],
            "status":    "error",
            "confidence": 0.0,
        }
