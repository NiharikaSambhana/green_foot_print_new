# ============================================================
# backend/rag/data_cleaner.py
# Clean + normalize performance logs and metrics before chunking
# ============================================================

import re, json
from typing import List
from langchain_core.documents import Document
from backend.core.logger import get_logger

logger = get_logger(__name__)

# ---- Noise patterns to strip from logs -----------------------
_NOISE = [
    r"\x1b\[[0-9;]*m",                      # ANSI color codes
    r"\b(DEBUG|TRACE)\b.*\n?",              # Debug/trace lines
    r"^\s*$",                                # Blank lines
    r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b",  # IP addresses (privacy)
    r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",  # Emails
]


def _clean_text(text: str) -> str:
    for pattern in _NOISE:
        text = re.sub(pattern, "", text, flags=re.MULTILINE)
    text = re.sub(r"\n{3,}", "\n\n", text)   # Max 2 blank lines
    text = text.strip()
    return text


def _normalize_metrics(text: str) -> str:
    """Standardize metric names for better embedding recall."""
    replacements = {
        r"\bcpu_usage\b": "CPU_UTILIZATION",
        r"\bcpu usage\b": "CPU_UTILIZATION",
        r"\bmem\b": "MEMORY",
        r"\blatency_ms\b": "LATENCY_MS",
        r"\bp99\b": "LATENCY_P99",
        r"\bp95\b": "LATENCY_P95",
        r"\berror.rate\b": "ERROR_RATE",
        r"\brps\b": "REQUESTS_PER_SECOND",
        r"\bthroughput\b": "REQUESTS_PER_SECOND",
        r"\boop\b": "OUT_OF_MEMORY",
        r"\boom\b": "OUT_OF_MEMORY",
        r"\bregression\b": "PERFORMANCE_REGRESSION",
    }
    for pattern, replacement in replacements.items():
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
    return text


def clean_documents(documents: List[Document]) -> List[Document]:
    """Clean and normalize all documents before embedding."""
    cleaned = []
    for doc in documents:
        original_len = len(doc.page_content)
        text = _clean_text(doc.page_content)
        text = _normalize_metrics(text)

        if len(text) < 20:               # Skip near-empty docs
            logger.debug(f"Skipped near-empty doc from {doc.metadata.get('source')}")
            continue

        doc.page_content = text
        doc.metadata["cleaned"] = True
        doc.metadata["original_length"] = original_len
        doc.metadata["cleaned_length"] = len(text)
        cleaned.append(doc)

    logger.info(f"Cleaned {len(cleaned)}/{len(documents)} documents")
    return cleaned
