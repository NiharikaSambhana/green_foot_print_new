# ============================================================
# backend/rag/document_loader.py
# Multimodal: PDF, CSV, JSON, TXT, LOG, ODS, XLSX, Images
# ============================================================

import os, json, base64
from pathlib import Path
from typing import List
import pandas as pd
from langchain_core.documents import Document
from backend.core.logger import get_logger

logger = get_logger(__name__)


# ============================================================
# IMAGE LOADER — uses Vision LLM to extract text
# ============================================================

def load_image(file_path: str) -> List[Document]:
    """Use Vision LLM to describe / extract text from image."""
    try:
        import base64
        from backend.core.http_client import sync_client
        from backend.core.config import settings

        with open(file_path, "rb") as f:
            img_b64 = base64.b64encode(f.read()).decode()

        ext = Path(file_path).suffix.lower().lstrip(".")
        mime = {"jpg": "image/jpeg", "jpeg": "image/jpeg",
                "png": "image/png", "gif": "image/gif"}.get(ext, "image/png")

        from langchain_openai import ChatOpenAI
        vision_llm = ChatOpenAI(
            base_url=settings.BASE_URL,
            model=settings.VISION_MODEL,
            api_key=settings.API_KEY,
            http_client=sync_client,
            max_tokens=1024,
        )

        from langchain_core.messages import HumanMessage
        msg = HumanMessage(content=[
            {"type": "image_url",
             "image_url": {"url": f"data:{mime};base64,{img_b64}"}},
            {"type": "text",
             "text": (
                 "You are analyzing a performance monitoring screenshot or chart. "
                 "Extract ALL visible text, metrics, values, labels, and trends. "
                 "List every number, timestamp, and metric name you see."
             )}
        ])
        result = vision_llm.invoke([msg])
        text = result.content
        logger.info(f"Vision extracted {len(text)} chars from {Path(file_path).name}")
        return [Document(page_content=text,
                         metadata={"source": file_path, "type": "image"})]
    except Exception as e:
        logger.error(f"Image load failed for {file_path}: {e}")
        return [Document(page_content=f"[Image load error: {e}]",
                         metadata={"source": file_path, "type": "image_error"})]


# ============================================================
# ODS / XLSX LOADER
# ============================================================

def load_spreadsheet(file_path: str) -> List[Document]:
    docs = []
    try:
        ext = Path(file_path).suffix.lower()
        engine = "odf" if ext == ".ods" else "openpyxl"
        xl = pd.ExcelFile(file_path, engine=engine)
        for sheet in xl.sheet_names:
            df = xl.parse(sheet).fillna("")
            text = f"Sheet: {sheet}\n{df.to_string(index=False)}"
            docs.append(Document(page_content=text,
                                 metadata={"source": file_path,
                                           "sheet": sheet, "type": ext}))
        logger.info(f"Loaded {len(docs)} sheets from {Path(file_path).name}")
    except Exception as e:
        logger.error(f"Spreadsheet load failed: {e}")
    return docs


# ============================================================
# JSON LOADER — Handles performance metric JSON files
# ============================================================

def load_json(file_path: str) -> List[Document]:
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        text = json.dumps(data, indent=2)
        return [Document(page_content=text,
                         metadata={"source": file_path, "type": "json"})]
    except Exception as e:
        logger.error(f"JSON load failed: {e}")
        return []


# ============================================================
# UNIVERSAL LOADER DISPATCHER
# ============================================================

def load_file(file_path: str) -> List[Document]:
    ext = Path(file_path).suffix.lower()
    name = Path(file_path).name
    logger.info(f"Loading: {name} ({ext})")

    if ext == ".pdf":
        from langchain_community.document_loaders import PyPDFLoader
        return PyPDFLoader(file_path).load()

    elif ext in (".txt", ".log"):
        from langchain_community.document_loaders import TextLoader
        return TextLoader(file_path, encoding="utf-8").load()

    elif ext == ".csv":
        from langchain_community.document_loaders import CSVLoader
        return CSVLoader(file_path).load()

    elif ext in (".xlsx", ".xls", ".ods"):
        return load_spreadsheet(file_path)

    elif ext == ".json":
        return load_json(file_path)

    elif ext in (".jpg", ".jpeg", ".png", ".gif"):
        return load_image(file_path)

    elif ext in (".docx",):
        from langchain_community.document_loaders import Docx2txtLoader
        return Docx2txtLoader(file_path).load()

    else:
        logger.warning(f"Unsupported file type: {ext}")
        return []


def load_folder(folder: str) -> List[Document]:
    docs = []
    for f in Path(folder).rglob("*"):
        if f.is_file() and not f.name.startswith("."):
            docs.extend(load_file(str(f)))
    logger.info(f"Folder load complete: {len(docs)} documents")
    return docs
