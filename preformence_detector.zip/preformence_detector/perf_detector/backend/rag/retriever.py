# ============================================================
# backend/rag/retriever.py
# Semantic retrieval + confidence scoring via logprobs
# ============================================================

import math
from typing import List, Dict, Any
from langchain_community.vectorstores import Chroma
from backend.core.config import settings
from backend.core.logger import get_logger

logger = get_logger(__name__)


def _distance_to_confidence(score: float) -> float:
    """Convert ChromaDB L2 distance → 0–100% confidence."""
    return round(max(0.0, (2.0 - score) / 2.0) * 100, 2)


def _logprob_confidence(logprobs_response) -> float:
    """
    Compute answer confidence from LLM logprobs.
    Average exp(logprob) across all output tokens → 0–100%.
    This is more meaningful than embedding distance alone.
    """
    try:
        if not logprobs_response:
            return 0.0
        tokens = logprobs_response.content[0].logprobs.content
        if not tokens:
            return 0.0
        avg_lp = sum(t.logprob for t in tokens) / len(tokens)
        return round(math.exp(avg_lp) * 100, 2)
    except Exception:
        return 0.0


class PerfRetriever:

    def __init__(self, vectordb: Chroma):
        self.vectordb = vectordb
        self.threshold = settings.SIMILARITY_THRESHOLD * 100

    def retrieve(
        self,
        query: str,
        k: int = None,
        filter_meta: Dict = None,
    ) -> List[Dict[str, Any]]:
        k = k or settings.RETRIEVAL_K
        try:
            results = self.vectordb.similarity_search_with_score(
                query, k=k, filter=filter_meta
            )
        except Exception as e:
            logger.error(f"Retrieval error: {e}")
            return []

        out = []
        for doc, score in sorted(results, key=lambda x: x[1]):
            conf = _distance_to_confidence(score)
            if conf < self.threshold:
                continue
            out.append({
                "content":    doc.page_content,
                "score":      round(score, 4),
                "confidence": conf,
                "source":     doc.metadata.get("source_file", "unknown"),
                "chunk_id":   doc.metadata.get("chunk_id", "N/A"),
                "doc_type":   doc.metadata.get("document_type", "unknown"),
                "metadata":   doc.metadata,
            })
        logger.info(f"Retrieved {len(out)} chunks for: '{query[:60]}'")
        return out

    def get_context(self, query: str, k: int = None) -> str:
        chunks = self.retrieve(query, k=k)
        if not chunks:
            return "No relevant context found in the knowledge base."
        parts = []
        for c in chunks:
            parts.append(
                f"[Source: {c['source']} | Confidence: {c['confidence']}%]\n{c['content']}"
            )
        return "\n\n---\n\n".join(parts)
