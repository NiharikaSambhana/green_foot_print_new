# ============================================================
# backend/rag/ingest.py
# Full pipeline: Load → Clean → Chunk → Embed → ChromaDB
# ============================================================

import os
from pathlib import Path
from typing import List
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma

from backend.core.config import settings
from backend.core.llm_factory import get_embedding_model
from backend.core.logger import get_logger
from backend.rag.document_loader import load_file, load_folder
from backend.rag.data_cleaner import clean_documents

logger = get_logger(__name__)


def chunk_documents(documents: List[Document]) -> List[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=settings.CHUNK_SIZE,
        chunk_overlap=settings.CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks = splitter.split_documents(documents)
    for idx, chunk in enumerate(chunks):
        src = chunk.metadata.get("source", "unknown")
        chunk.metadata.update({
            "chunk_id":      idx,
            "source_file":   src,
            "document_type": Path(src).suffix if src != "unknown" else "unknown",
            "chunk_length":  len(chunk.page_content),
            "collection":    settings.COLLECTION_NAME,
        })
    logger.info(f"Created {len(chunks)} chunks")
    return chunks


def build_vector_db(
    file_paths: List[str] = None,
    folder: str = None,
    force_rebuild: bool = False,
) -> Chroma:
    """
    Build or update ChromaDB.
    Pass file_paths for uploaded files, folder for batch ingest.
    """
    db_path = settings.VECTOR_DB_PATH
    embeddings = get_embedding_model()

    if file_paths:
        # Incremental: add new files to existing DB
        docs = []
        for fp in file_paths:
            docs.extend(load_file(fp))
        docs   = clean_documents(docs)
        chunks = chunk_documents(docs)

        if os.path.exists(db_path) and not force_rebuild:
            vectordb = Chroma(
                persist_directory=db_path,
                embedding_function=embeddings,
                collection_name=settings.COLLECTION_NAME,
            )
            vectordb.add_documents(chunks)
        else:
            vectordb = Chroma.from_documents(
                documents=chunks,
                embedding=embeddings,
                persist_directory=db_path,
                collection_name=settings.COLLECTION_NAME,
            )
        vectordb.persist()
        logger.info(f"Added {len(chunks)} chunks to vector DB")
        return vectordb

    if folder:
        docs   = load_folder(folder)
        docs   = clean_documents(docs)
        chunks = chunk_documents(docs)
        vectordb = Chroma.from_documents(
            documents=chunks,
            embedding=embeddings,
            persist_directory=db_path,
            collection_name=settings.COLLECTION_NAME,
        )
        vectordb.persist()
        return vectordb

    raise ValueError("Provide either file_paths or folder")


def load_vector_db() -> Chroma:
    return Chroma(
        persist_directory=settings.VECTOR_DB_PATH,
        embedding_function=get_embedding_model(),
        collection_name=settings.COLLECTION_NAME,
    )
