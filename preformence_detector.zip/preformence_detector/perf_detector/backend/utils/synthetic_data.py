# ============================================================
# backend/utils/synthetic_data.py
# Generate synthetic regression scenarios for demo
# ============================================================

import json, random
from datetime import datetime, timedelta
from typing import List, Dict


def generate_metrics_series(
    hours: int = 24,
    inject_regression_at: int = 18,   # hour index
) -> List[Dict]:
    """
    Generate a time series of performance metrics with
    a simulated regression injected at a specific hour.
    """
    series = []
    base_time = datetime.utcnow() - timedelta(hours=hours)

    for i in range(hours * 12):           # Every 5 minutes
        t = base_time + timedelta(minutes=i * 5)
        is_regression = i >= inject_regression_at * 12

        # Normal baseline
        cpu    = random.uniform(30, 55)
        memory = random.uniform(45, 65)
        latency= random.uniform(120, 280)
        errors = random.uniform(0, 1.5)
        rps    = random.uniform(800, 1200)

        if is_regression:
            # Inject regression spikes
            cpu     += random.uniform(35, 50)          # CPU spike
            memory  += random.uniform(20, 30)          # Memory pressure
            latency += random.uniform(1500, 3000)      # Latency explosion
            errors  += random.uniform(5, 15)           # Error rate surge
            rps     *= random.uniform(0.3, 0.6)        # Throughput drop

        series.append({
            "timestamp":    t.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "cpu_pct":      round(min(cpu, 100), 2),
            "memory_pct":   round(min(memory, 100), 2),
            "latency_ms":   round(latency, 2),
            "error_rate":   round(min(errors, 100), 2),
            "rps":          round(rps, 2),
            "is_regression": is_regression,
        })

    return series


def generate_log_entries(count: int = 200, include_errors: bool = True) -> str:
    """Generate synthetic application log entries."""
    log_templates = [
        "[INFO]  {ts} RequestHandler: GET /api/checkout 200 {lat}ms",
        "[INFO]  {ts} DB: query executed in {lat}ms rows={rows}",
        "[WARN]  {ts} ConnectionPool: pool utilization at {pct}%",
        "[ERROR] {ts} Service: timeout after {lat}ms — {svc}",
        "[ERROR] {ts} OOMError: memory limit exceeded on pod {pod}",
        "[INFO]  {ts} Deploy: version v{ver} rolled out to {env}",
        "[WARN]  {ts} CPU throttling detected: {pct}% usage",
        "[ERROR] {ts} CircuitBreaker: OPEN for {svc} — error rate {pct}%",
        "[INFO]  {ts} HealthCheck: /health 200 OK",
        "[WARN]  {ts} GC pause: {lat}ms — heap at {pct}%",
    ]

    lines = []
    base  = datetime.utcnow() - timedelta(minutes=count)
    for i in range(count):
        t   = base + timedelta(minutes=i)
        ts  = t.strftime("%Y-%m-%dT%H:%M:%SZ")
        tpl = random.choice(log_templates)
        line = tpl.format(
            ts=ts,
            lat=random.randint(50, 5000),
            rows=random.randint(1, 1000),
            pct=random.randint(60, 99),
            svc=random.choice(["checkout-svc", "auth-svc", "payment-svc", "inventory-svc"]),
            pod=f"pod-{random.randint(1, 20):03d}",
            ver=f"{random.randint(1,3)}.{random.randint(0,9)}.{random.randint(0,9)}",
            env=random.choice(["prod", "staging"]),
        )
        lines.append(line)
    return "\n".join(lines)


def generate_historical_incidents() -> List[Dict]:
    """Generate past regression incident records for RAG context."""
    return [
        {
            "incident_id": "INC-2024-001",
            "date": "2024-03-15T14:30:00Z",
            "severity": "P1",
            "service": "checkout-svc",
            "root_cause": "Memory leak in v2.3.1 — DB connection pool not released",
            "metrics": {"cpu_peak": 94.2, "memory_peak": 97.1, "latency_p99": 4200},
            "resolution": "Rollback to v2.2.8, patched in v2.3.2",
            "time_to_detect": "23 minutes",
            "time_to_resolve": "47 minutes",
        },
        {
            "incident_id": "INC-2024-002",
            "date": "2024-06-22T09:15:00Z",
            "severity": "P2",
            "service": "auth-svc",
            "root_cause": "Unindexed DB query after schema migration caused N+1 queries",
            "metrics": {"cpu_peak": 78.5, "memory_peak": 65.2, "latency_p99": 3100},
            "resolution": "Added composite index, query optimized",
            "time_to_detect": "12 minutes",
            "time_to_resolve": "2.5 hours",
        },
        {
            "incident_id": "INC-2024-003",
            "date": "2024-09-08T22:00:00Z",
            "severity": "P2",
            "service": "payment-svc",
            "root_cause": "Third-party payment gateway latency spike propagated via synchronous calls",
            "metrics": {"cpu_peak": 55.1, "memory_peak": 60.3, "latency_p99": 8900},
            "resolution": "Implemented circuit breaker + async fallback",
            "time_to_detect": "8 minutes",
            "time_to_resolve": "1.2 hours",
        },
    ]


def save_sample_data(output_dir: str = "data"):
    """Save synthetic data files to disk for demo."""
    import os
    os.makedirs(output_dir, exist_ok=True)

    # Metrics JSON
    metrics = generate_metrics_series(hours=24, inject_regression_at=18)
    with open(f"{output_dir}/metrics_timeseries.json", "w") as f:
        json.dump(metrics, f, indent=2)

    # Logs TXT
    logs = generate_log_entries(count=300)
    with open(f"{output_dir}/application.log", "w") as f:
        f.write(logs)

    # Historical incidents JSON
    incidents = generate_historical_incidents()
    with open(f"{output_dir}/historical_incidents.json", "w") as f:
        json.dump(incidents, f, indent=2)

    print(f"✅ Sample data saved to {output_dir}/")


if __name__ == "__main__":
    save_sample_data()
