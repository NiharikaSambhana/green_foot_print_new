# ============================================================
# backend/evaluation/metrics.py
# RAG + Agent evaluation metrics
# ============================================================

import math
from typing import List, Dict, Any
from backend.core.logger import get_logger

logger = get_logger(__name__)


def _token_overlap(a: str, b: str) -> float:
    """Simple token-level F1 overlap."""
    a_toks = set(a.lower().split())
    b_toks = set(b.lower().split())
    if not a_toks or not b_toks:
        return 0.0
    inter = a_toks & b_toks
    prec  = len(inter) / len(a_toks)
    rec   = len(inter) / len(b_toks)
    if prec + rec == 0:
        return 0.0
    return round(2 * prec * rec / (prec + rec), 4)


def compute_rouge1(answer: str, reference: str) -> Dict[str, float]:
    try:
        from rouge_score import rouge_scorer
        scorer = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"])
        scores = scorer.score(reference, answer)
        return {
            "rouge1_f1": round(scores["rouge1"].fmeasure, 4),
            "rouge2_f1": round(scores["rouge2"].fmeasure, 4),
            "rougeL_f1": round(scores["rougeL"].fmeasure, 4),
        }
    except Exception:
        return {"rouge1_f1": 0.0, "rouge2_f1": 0.0, "rougeL_f1": 0.0}


def grounding_score(answer: str, context_chunks: List[str]) -> float:
    """How well is the answer grounded in retrieved context?"""
    if not context_chunks:
        return 0.0
    scores = [_token_overlap(answer, chunk) for chunk in context_chunks]
    return round(sum(scores) / len(scores) * 100, 2)


def faithfulness_score(answer: str, context: str) -> float:
    """Rough faithfulness — answer word coverage from context."""
    ans_words   = set(answer.lower().split())
    ctx_words   = set(context.lower().split())
    if not ans_words:
        return 0.0
    covered = ans_words & ctx_words
    return round(len(covered) / len(ans_words) * 100, 2)


def anomaly_detection_accuracy(
    detected: List[dict],
    ground_truth: List[dict],
) -> Dict[str, float]:
    """
    Compare detected anomalies vs known ground truth.
    Each item must have a 'metric' key.
    """
    detected_set = {d.get("metric", "").upper() for d in detected}
    truth_set    = {t.get("metric", "").upper() for t in ground_truth}

    if not truth_set:
        return {"precision": 0.0, "recall": 0.0, "f1": 0.0}

    tp = len(detected_set & truth_set)
    fp = len(detected_set - truth_set)
    fn = len(truth_set - detected_set)

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1        = (2 * precision * recall / (precision + recall)
                 if (precision + recall) > 0 else 0.0)

    return {
        "precision": round(precision, 4),
        "recall":    round(recall, 4),
        "f1":        round(f1, 4),
    }


def evaluate_response(
    query: str,
    answer: str,
    context_chunks: List[str],
    reference_answer: str = "",
    detected_anomalies: List[dict] = None,
    ground_truth_anomalies: List[dict] = None,
) -> Dict[str, Any]:
    """Full evaluation report for one query-answer pair."""
    results: Dict[str, Any] = {}

    results["grounding_score"]   = grounding_score(answer, context_chunks)
    results["faithfulness_score"] = faithfulness_score(answer, " ".join(context_chunks))

    if reference_answer:
        results["rouge"] = compute_rouge1(answer, reference_answer)

    if detected_anomalies is not None and ground_truth_anomalies is not None:
        results["detection_accuracy"] = anomaly_detection_accuracy(
            detected_anomalies, ground_truth_anomalies)

    results["answer_length"]      = len(answer.split())
    results["context_used"]       = len(context_chunks)
    results["overall_quality"]    = round(
        (results["grounding_score"] + results["faithfulness_score"]) / 2, 2)

    logger.info(f"Evaluation complete: grounding={results['grounding_score']}% "
                f"faithfulness={results['faithfulness_score']}%")
    return results
