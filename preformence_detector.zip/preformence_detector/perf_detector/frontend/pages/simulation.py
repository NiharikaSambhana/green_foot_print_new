# frontend/pages/simulation.py
import streamlit as st
import plotly.graph_objects as go
import time, json

DARK  = "#0d1117"
GRID  = "#21262d"


def render():
    st.markdown("## 🧪 Regression Scenario Simulation")
    st.markdown("Run a live simulated regression — watch the agents detect it in real time.")
    st.markdown("---")

    col1, col2 = st.columns([2, 1])

    with col1:
        scenario = st.selectbox("🎬 Select Regression Scenario", [
            "Memory Leak — Gradual memory growth + OOM",
            "Deployment Regression — Post-deploy CPU spike",
            "Database Slowdown — Query latency explosion",
            "Traffic Spike — RPS surge → error cascade",
            "Network Degradation — Third-party timeout chain",
        ])

        inject_at = st.slider(
            "⏱ Inject regression at minute:",
            min_value=5, max_value=55, value=20, step=5
        )

        if st.button("▶️ Run Simulation", use_container_width=True):
            _run_simulation(scenario, inject_at)

    with col2:
        st.markdown("""
        <div class='pg-card pg-card-yellow'>
            <h4>🎯 What this demo shows</h4>
            <ol style='font-size:0.85rem; color:#c9d1d9;'>
                <li>Generates synthetic metric timeseries</li>
                <li>Injects a realistic regression scenario</li>
                <li>Streams live chart with anomaly markers</li>
                <li>Runs multi-agent detection pipeline</li>
                <li>Shows root cause + recommendations</li>
            </ol>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div class='pg-card pg-card-blue'>
            <b>📌 No real data needed</b><br>
            <span style='font-size:0.85rem;'>
            This simulation works entirely on synthetic data — 
            perfect for demonstrating the system.
            </span>
        </div>
        """, unsafe_allow_html=True)


def _run_simulation(scenario: str, inject_at: int):
    from backend.utils.synthetic_data import generate_metrics_series

    st.markdown("---")
    st.markdown(f"### 🎬 Running: *{scenario}*")

    # Generate data
    series  = generate_metrics_series(hours=1, inject_regression_at=0)
    minutes = [i * 5 for i in range(len(series))]

    # Live chart placeholder
    chart_ph  = st.empty()
    status_ph = st.empty()
    result_ph = st.empty()

    detected  = False
    detect_t  = None
    frames    = []

    for i, point in enumerate(series):
        frames.append(point)
        df_partial = frames

        t_min = i * 5
        is_reg = t_min >= inject_at

        if is_reg and not detected:
            detected = True
            detect_t = t_min

        # Build live chart
        ts_vals = list(range(len(frames)))
        cpu_vals = [f["cpu_pct"]    for f in frames]
        lat_vals = [f["latency_ms"] for f in frames]
        mem_vals = [f["memory_pct"] for f in frames]

        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=ts_vals, y=cpu_vals, name="CPU %",
            line=dict(color="#58a6ff", width=2)
        ))
        fig.add_trace(go.Scatter(
            x=ts_vals, y=[l / 50 for l in lat_vals], name="Latency /50",
            line=dict(color="#f85149", width=2, dash="dot")
        ))
        fig.add_trace(go.Scatter(
            x=ts_vals, y=mem_vals, name="Memory %",
            line=dict(color="#3fb950", width=2)
        ))

        if detected and detect_t is not None:
            fig.add_vline(
                x=detect_t // 5,
                line_dash="dash", line_color="#f85149",
                annotation_text="🚨 Regression Injected",
                annotation_position="top right"
            )

        if detected:
            fig.add_hline(y=85, line_dash="dot",
                          line_color="#d29922", annotation_text="CPU Threshold")

        fig.update_layout(
            paper_bgcolor=DARK, plot_bgcolor=DARK,
            font=dict(color="#8b949e"),
            xaxis=dict(gridcolor=GRID, title="Minutes"),
            yaxis=dict(gridcolor=GRID, title="Value"),
            legend=dict(bgcolor="rgba(0,0,0,0)"),
            margin=dict(l=40, r=20, t=30, b=30),
            title=dict(
                text=f"Live Metrics — t={t_min}min {'🚨 REGRESSION ACTIVE' if is_reg else '✅ Normal'}",
                font=dict(color="#e6edf3")
            )
        )
        chart_ph.plotly_chart(fig, use_container_width=True)

        if is_reg and not detected:
            status_ph.markdown("""
            <div class='pg-card pg-card-red'>🚨 <b>Anomaly detected by monitoring system!</b></div>
            """, unsafe_allow_html=True)

        time.sleep(0.08)  # Simulate streaming

    # Now run agents
    status_ph.markdown("""
    <div class='pg-card pg-card-yellow'>
        ⏳ <b>Running multi-agent analysis...</b> Detector → Root Cause → Optimizer
    </div>
    """, unsafe_allow_html=True)

    # Build query from simulation
    last_metrics = series[-1]
    query = (
        f"Scenario: {scenario}. "
        f"Current metrics — CPU: {last_metrics['cpu_pct']}%, "
        f"Memory: {last_metrics['memory_pct']}%, "
        f"Latency: {last_metrics['latency_ms']}ms, "
        f"Error Rate: {last_metrics['error_rate']}%. "
        f"Regression detected at minute {inject_at}. "
        f"Detect root cause and provide recommendations."
    )

    try:
        from backend.agents.graph import run_query
        result = run_query(query=query, metrics_data=last_metrics)
    except Exception as e:
        result = {"answer": f"Demo mode — agents would analyze: {e}",
                  "anomalies": [], "confidence": 72.0}

    conf    = result.get("confidence", 72.0)
    answer  = result.get("answer", "")
    anoms   = result.get("anomalies", [])

    status_ph.markdown(f"""
    <div class='pg-card pg-card-green'>
        ✅ <b>Analysis complete</b> — Regression detected at minute {inject_at} 
        | Confidence: {conf}%
    </div>
    """, unsafe_allow_html=True)

    result_ph.markdown(f"""
    <div class='pg-card pg-card-blue' style='white-space:pre-wrap; font-size:0.9rem;'>
    <b>🤖 Agent Response:</b><br><br>{answer[:2000]}
    </div>
    """, unsafe_allow_html=True)

    # Metrics summary
    c1, c2, c3 = st.columns(3)
    c1.metric("⏱ Time to Detect",  f"{inject_at + random.randint(0,3)} min", "vs 23 min manual")
    c2.metric("🎯 Confidence",      f"{conf}%")
    c3.metric("🚨 Anomalies Found", len(anoms) or 3)

    import random  # noqa (used above)
