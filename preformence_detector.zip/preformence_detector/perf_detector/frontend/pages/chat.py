# frontend/pages/chat.py
import streamlit as st
import uuid

def render():
    st.markdown("## 🤖 PerfGuard AI Assistant")
    st.markdown("Ask anything about your application performance — agents will answer with context from your data.")
    st.markdown("---")

    # Init session
    if "chat_messages" not in st.session_state:
        st.session_state.chat_messages = []
    if "session_id" not in st.session_state:
        st.session_state.session_id = str(uuid.uuid4())

    # Sidebar controls
    with st.sidebar:
        st.markdown("---")
        st.markdown("**💬 Chat Options**")
        agent_override = st.selectbox(
            "Force agent (optional)",
            ["Auto", "detector", "root_cause", "optimizer", "reporter", "rag_agent"],
            key="chat_agent"
        )
        use_pipeline = st.checkbox("Multi-agent pipeline", key="chat_pipeline")
        if st.button("🗑️ Clear Chat", key="clear_chat"):
            st.session_state.chat_messages = []
            st.session_state.session_id = str(uuid.uuid4())
            st.rerun()

    # Quick suggestion pills
    suggestions = [
        "Detect anomalies in recent metrics",
        "What caused the latency spike?",
        "How can I reduce CPU usage?",
        "Generate a regression report",
        "What is P99 latency?",
    ]
    st.markdown("**💡 Try asking:**")
    cols = st.columns(len(suggestions))
    for col, sug in zip(cols, suggestions):
        if col.button(sug, key=f"sug_{sug[:15]}", use_container_width=True):
            st.session_state._pending_query = sug
            st.rerun()

    st.markdown("---")

    # Chat history
    chat_container = st.container()
    with chat_container:
        for msg in st.session_state.chat_messages:
            role = msg["role"]
            with st.chat_message(role, avatar="🧑‍💻" if role == "user" else "🛡️"):
                st.markdown(msg["content"])
                if msg.get("confidence"):
                    conf = msg["confidence"]
                    cls  = "conf-high" if conf >= 75 else "conf-medium" if conf >= 50 else "conf-low"
                    st.markdown(
                        f"<span class='{cls}' style='font-size:0.75rem;'>🎯 Confidence: {conf}%</span>",
                        unsafe_allow_html=True
                    )
                if msg.get("anomalies"):
                    _show_anomaly_chips(msg["anomalies"])

    # Input
    pending = st.session_state.pop("_pending_query", None)
    user_input = st.chat_input("Ask about performance regressions...") or pending

    if user_input:
        st.session_state.chat_messages.append({"role": "user", "content": user_input})

        with st.chat_message("user", avatar="🧑‍💻"):
            st.markdown(user_input)

        with st.chat_message("assistant", avatar="🛡️"):
            with st.spinner("Analyzing..."):
                try:
                    from backend.agents.graph import run_query
                    result = run_query(
                        query=user_input,
                        session_id=st.session_state.session_id,
                    )
                    answer     = result.get("answer", "No response")
                    confidence = result.get("confidence", 0)
                    anomalies  = result.get("anomalies", [])
                except Exception as e:
                    answer     = f"❌ Error: {str(e)}"
                    confidence = 0
                    anomalies  = []

            st.markdown(answer)
            conf_cls = "conf-high" if confidence >= 75 else "conf-medium" if confidence >= 50 else "conf-low"
            st.markdown(
                f"<span class='{conf_cls}' style='font-size:0.75rem;'>🎯 Confidence: {confidence}%</span>",
                unsafe_allow_html=True
            )
            if anomalies:
                _show_anomaly_chips(anomalies)

        st.session_state.chat_messages.append({
            "role":       "assistant",
            "content":    answer,
            "confidence": confidence,
            "anomalies":  anomalies,
        })


def _show_anomaly_chips(anomalies):
    chips = ""
    for a in anomalies[:4]:
        sev = a.get("severity", "MEDIUM").upper()
        cls = {"CRITICAL":"sev-critical","HIGH":"sev-high",
               "MEDIUM":"sev-medium","LOW":"sev-low"}.get(sev,"sev-medium")
        chips += f"<span class='{cls}' style='margin-right:6px;'>{a.get('metric','?')}: {a.get('value','?')}</span>"
    if chips:
        st.markdown(f"<div style='margin-top:6px;'>{chips}</div>", unsafe_allow_html=True)
