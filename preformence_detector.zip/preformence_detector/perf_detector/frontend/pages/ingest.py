# frontend/pages/ingest.py
import streamlit as st
import tempfile, os, json
from pathlib import Path

def render():
    st.markdown("## 📤 Upload & Ingest Performance Data")
    st.markdown("Supports: **PDF · CSV · JSON · TXT · LOG · ODS · XLSX · PNG/JPG**")
    st.markdown("---")

    col1, col2 = st.columns([2, 1])

    with col1:
        uploaded = st.file_uploader(
            "Drop your files here",
            type=["pdf","csv","json","txt","log","ods","xlsx","xls","png","jpg","jpeg","docx"],
            accept_multiple_files=True,
            help="Upload performance metrics, application logs, incident reports, or screenshots"
        )

        force_rebuild = st.checkbox(
            "🔄 Force rebuild vector DB (clears existing data)",
            value=False
        )

        if uploaded:
            st.markdown(f"**{len(uploaded)} file(s) selected:**")
            for f in uploaded:
                size_kb = round(f.size / 1024, 1)
                icon = {
                    "pdf":"📄","csv":"📊","json":"🗂️","txt":"📝",
                    "log":"📋","ods":"📊","xlsx":"📊","xls":"📊",
                    "png":"🖼️","jpg":"🖼️","jpeg":"🖼️","docx":"📄"
                }.get(f.name.split(".")[-1].lower(), "📁")
                st.markdown(f"""
                <div class='pg-card' style='padding:0.6rem 1rem; margin-bottom:0.4rem;
                            display:flex; justify-content:space-between;'>
                    <span>{icon} <b>{f.name}</b></span>
                    <span style='color:#8b949e;'>{size_kb} KB</span>
                </div>
                """, unsafe_allow_html=True)

            if st.button("🚀 Ingest Files into Vector DB", use_container_width=True):
                _ingest_files(uploaded, force_rebuild)

    with col2:
        st.markdown("""
        <div class='pg-card pg-card-blue'>
            <h4>📌 What to Upload</h4>
            <ul style='font-size:0.85rem;'>
                <li><b>JSON/CSV</b> — metrics timeseries (CPU, memory, latency)</li>
                <li><b>LOG/TXT</b> — application server logs</li>
                <li><b>PDF</b> — incident reports, runbooks</li>
                <li><b>Images</b> — Grafana/dashboard screenshots</li>
                <li><b>ODS/XLSX</b> — historical performance data</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div class='pg-card pg-card-yellow'>
            <h4>💡 Tip</h4>
            <p style='font-size:0.85rem;'>
                Upload historical incident data alongside current 
                metrics for better root cause analysis.
            </p>
        </div>
        """, unsafe_allow_html=True)

        # DB status
        db_exists = os.path.exists("vectordb/chroma_db")
        status_card = "pg-card-green" if db_exists else "pg-card-red"
        status_text = "✅ Vector DB Ready" if db_exists else "⚠️ No Vector DB yet"
        st.markdown(f"""
        <div class='pg-card {status_card}'>
            <b>{status_text}</b>
        </div>
        """, unsafe_allow_html=True)

    # Show ingestion history
    if "ingest_history" in st.session_state and st.session_state.ingest_history:
        st.markdown("---")
        st.markdown("### 📋 Ingestion History")
        for entry in reversed(st.session_state.ingest_history[-5:]):
            st.markdown(f"""
            <div class='pg-card' style='padding:0.5rem 1rem;'>
                ✅ <b>{entry['file']}</b> — {entry['chunks']} chunks — {entry['time']}
            </div>
            """, unsafe_allow_html=True)


def _ingest_files(uploaded_files, force_rebuild: bool):
    from datetime import datetime
    progress = st.progress(0, text="Starting ingestion...")
    status   = st.empty()
    total    = len(uploaded_files)

    tmp_paths = []
    for i, f in enumerate(uploaded_files):
        progress.progress((i + 1) / (total + 1), text=f"Saving {f.name}...")
        suffix = Path(f.name).suffix
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(f.read())
            tmp_paths.append((f.name, tmp.name))

    try:
        from backend.rag.ingest import build_vector_db
        progress.progress(0.6, text="Building embeddings...")
        paths = [p for _, p in tmp_paths]
        build_vector_db(file_paths=paths, force_rebuild=force_rebuild)

        progress.progress(1.0, text="Done!")
        status.success(f"✅ Successfully ingested {total} file(s) into Vector DB!")

        if "ingest_history" not in st.session_state:
            st.session_state.ingest_history = []

        for fname, _ in tmp_paths:
            st.session_state.ingest_history.append({
                "file": fname,
                "chunks": "~",
                "time": datetime.now().strftime("%H:%M:%S"),
            })

    except Exception as e:
        status.error(f"❌ Ingestion failed: {e}")
    finally:
        for _, p in tmp_paths:
            try: os.unlink(p)
            except: pass
