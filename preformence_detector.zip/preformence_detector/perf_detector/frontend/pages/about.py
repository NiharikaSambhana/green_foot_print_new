# frontend/pages/about.py
import streamlit as st

def render():
    st.markdown("## ℹ️ About PerfGuard AI")
    st.markdown("---")

    st.markdown("""
    <div class='pg-card pg-card-blue'>
        <h3>🎯 Problem Statement</h3>
        <p>Application performance regressions negatively impact user experience but are often 
        detected late due to manual log analysis and monitoring alert noise. Identifying root 
        causes requires expert analysis, delaying remediation. PerfGuard AI solves this with 
        a generative AI pipeline that detects regressions early and explains root causes in 
        natural language.</p>
    </div>
    """, unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        st.markdown("""
        <div class='pg-card'>
            <h3>🏗️ Architecture</h3>
            <ul>
                <li><b>LangGraph</b> — Multi-agent orchestration</li>
                <li><b>ChromaDB</b> — Vector database</li>
                <li><b>DeepSeek-V3</b> — Main chat model</li>
                <li><b>DeepSeek-R1</b> — Root cause reasoning</li>
                <li><b>Llama-3.2-90B Vision</b> — Image/chart parsing</li>
                <li><b>text-embedding-3-large</b> — Embeddings</li>
                <li><b>Streamlit</b> — Frontend UI</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    with c2:
        st.markdown("""
        <div class='pg-card'>
            <h3>🤖 Agent Roles</h3>
            <table style='width:100%; font-size:0.85rem; color:#c9d1d9;'>
                <tr><td><b>Supervisor</b></td><td>Intelligent query routing</td></tr>
                <tr><td><b>Detector</b></td><td>Anomaly detection in metrics/logs</td></tr>
                <tr><td><b>Root Cause</b></td><td>Deep reasoning (DeepSeek-R1)</td></tr>
                <tr><td><b>Optimizer</b></td><td>Ranked remediation steps</td></tr>
                <tr><td><b>Reporter</b></td><td>Formal incident reports</td></tr>
                <tr><td><b>RAG Agent</b></td><td>KB Q&A with citations</td></tr>
            </table>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("""
    <div class='pg-card pg-card-green'>
        <h3>📊 Key Features</h3>
        <div style='display:grid; grid-template-columns:1fr 1fr; gap:0.5rem; font-size:0.9rem;'>
            <span>✅ Multimodal ingestion (PDF/CSV/Images/ODS)</span>
            <span>✅ LangGraph multi-agent orchestration</span>
            <span>✅ Confidence scoring via logprobs</span>
            <span>✅ Data cleaning + normalization pipeline</span>
            <span>✅ Semantic retrieval with ChromaDB</span>
            <span>✅ Built-in evaluation (ROUGE/grounding)</span>
            <span>✅ Live regression simulation</span>
            <span>✅ Downloadable incident reports</span>
            <span>✅ Prompt engineering (Role/Context/Problem/Example)</span>
            <span>✅ Privacy-safe (PII scrubbing in guardrails)</span>
        </div>
    </div>
    """, unsafe_allow_html=True)
