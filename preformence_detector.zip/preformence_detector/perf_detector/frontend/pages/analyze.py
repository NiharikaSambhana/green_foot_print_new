# frontend/pages/analyze.py
import streamlit as st
import json, tempfile, os
from pathlib import Path

def render():
    st.markdown("## 🔍 Analyze & Detect Regressions")
    st.markdown("Upload metrics or describe the issue — agents will detect anomalies and find root causes.")
    st.markdown("---")

    tab1, tab2 = st.tabs(["📊 Upload Metrics File", "✍️ Describe Issue"])

    # ---- TAB 1: File upload analysis ----
    with tab1:
        col1, col2 = st.columns([2, 1])
        with col1:
            metrics_file = st.file_uploader(
                "Upload performance metrics (JSON or CSV)",
                type=["json", "csv"],
                key="metrics_upload"
            )
            agent_choice = st.selectbox(
                "🤖 Analysis Mode",
                ["🔄 Auto-Route (Recommended)", "🔍 Detector Only",
                 "🧠 Root Cause Only", "💡 Optimizer", "📋 Full Report"],
                help="Auto-route lets the Supervisor Agent decide the best agent"
            )

            agent_map = {
                "🔄 Auto-Route (Recommended)": None,
                "🔍 Detector Only":            "detector",
                "🧠 Root Cause Only":          "root_cause",
                "💡 Optimizer":                "optimizer",
                "📋 Full Report":              "reporter",
            }

            run_pipeline = st.checkbox(
                "🔗 Run full pipeline (Detect → RCA → Optimize → Report)",
                value=False
            )

            if st.button("🚀 Analyze", use_container_width=True, key="analyze_btn"):
                if not metrics_file:
                    st.warning("Please upload a metrics file first.")
                    return
                _run_analysis_from_file(
                    metrics_file,
                    agent_map[agent_choice],
                    run_pipeline
                )

        with col2:
            st.markdown("""
            <div class='pg-card pg-card-blue'>
                <h4>📌 Expected Format</h4>
                <b>JSON metrics:</b><br>
                <code style='font-size:0.75rem; color:#a5d6ff;'>
                [{"timestamp":"...",<br>
                &nbsp;&nbsp;"cpu_pct": 85.2,<br>
                &nbsp;&nbsp;"memory_pct": 91.0,<br>
                &nbsp;&nbsp;"latency_ms": 2300,<br>
                &nbsp;&nbsp;"error_rate": 7.2}]
                </code><br><br>
                <b>CSV metrics:</b><br>
                <code style='font-size:0.75rem; color:#a5d6ff;'>
                timestamp,cpu_pct,memory_pct,latency_ms
                </code>
            </div>
            """, unsafe_allow_html=True)

    # ---- TAB 2: Text query ----
    with tab2:
        query = st.text_area(
            "Describe the performance issue or ask a question",
            placeholder=(
                "e.g. 'CPU spiked to 95% after the 2pm deployment. "
                "Memory usage is at 88% and latency jumped from 200ms to 2800ms. "
                "What is the root cause?'"
            ),
            height=140
        )

        c1, c2 = st.columns(2)
        with c1:
            agent_txt = st.selectbox(
                "Agent",
                ["Auto", "detector", "root_cause", "optimizer", "reporter", "rag_agent"],
                key="agent_txt"
            )
        with c2:
            pipeline_txt = st.checkbox("Run pipeline", key="pipeline_txt")

        if st.button("🔍 Analyze Issue", use_container_width=True, key="analyze_txt_btn"):
            if not query.strip():
                st.warning("Please describe the issue.")
                return
            _run_text_analysis(
                query,
                None if agent_txt == "Auto" else agent_txt,
                pipeline_txt
            )


# ---- Helpers ----

def _run_analysis_from_file(f, agent_name, run_pipeline):
    suffix = Path(f.name).suffix.lower()
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(f.read())
        tmp_path = tmp.name

    try:
        metrics_data = {}
        if suffix == ".json":
            with open(tmp_path) as fp:
                raw = json.load(fp)
            metrics_data = raw if isinstance(raw, dict) else {"data": raw}
            query = (
                f"Analyze this performance metrics data for regressions: "
                f"{json.dumps(raw[:5] if isinstance(raw, list) else raw, indent=2)}"
            )
        else:  # CSV
            import pandas as pd
            df = pd.read_csv(tmp_path)
            query = (
                f"Analyze this performance data for regressions:\n"
                f"{df.describe().to_string()}\n\nSample rows:\n{df.head(10).to_string()}"
            )
            metrics_data = df.to_dict()

        _display_analysis(query, metrics_data, agent_name, run_pipeline)

    finally:
        os.unlink(tmp_path)


def _run_text_analysis(query, agent_name, run_pipeline):
    _display_analysis(query, {}, agent_name, run_pipeline)


def _display_analysis(query, metrics_data, agent_name, run_pipeline):
    with st.spinner("🤖 Agents analyzing... (this may take 20-40 seconds)"):
        try:
            from backend.agents.graph import run_query
            result = run_query(
                query=query,
                metrics_data=metrics_data,
            )
        except Exception as e:
            st.error(f"Analysis failed: {e}")
            return

    # Store for dashboard
    if "alert_history" not in st.session_state:
        st.session_state.alert_history = []
    st.session_state.alert_history.append({
        "query":     query[:80] + "...",
        "anomalies": result.get("anomalies", []),
        "confidence":result.get("confidence", 0),
        "status":    result.get("status"),
    })

    # --- Confidence badge ---
    conf = result.get("confidence", 0)
    conf_class = "conf-high" if conf >= 75 else "conf-medium" if conf >= 50 else "conf-low"
    st.markdown(f"""
    <div class='pg-card' style='display:flex; justify-content:space-between; align-items:center;'>
        <span>Analysis complete</span>
        <span class='{conf_class}'>🎯 Confidence: {conf}%</span>
    </div>
    """, unsafe_allow_html=True)

    # --- Anomalies ---
    anomalies = result.get("anomalies", [])
    if anomalies:
        st.markdown("### 🚨 Detected Anomalies")
        cols = st.columns(min(len(anomalies), 3))
        for i, a in enumerate(anomalies):
            sev   = a.get("severity", "MEDIUM").upper()
            sev_class = {"CRITICAL":"sev-critical","HIGH":"sev-high",
                         "MEDIUM":"sev-medium","LOW":"sev-low"}.get(sev, "sev-medium")
            card_class = {"CRITICAL":"pg-card-red","HIGH":"pg-card-red",
                          "MEDIUM":"pg-card-yellow","LOW":"pg-card-green"}.get(sev, "pg-card-yellow")
            cols[i % 3].markdown(f"""
            <div class='pg-card {card_class}'>
                <span class='{sev_class}'>{sev}</span><br>
                <b style='color:#e6edf3;'>{a.get("metric","Unknown")}</b><br>
                <span style='font-size:0.85rem; color:#8b949e;'>
                    Value: {a.get("value","N/A")} | Threshold: {a.get("threshold","N/A")}
                </span><br>
                <span style='font-size:0.8rem; color:#c9d1d9;'>{a.get("description","")}</span>
            </div>
            """, unsafe_allow_html=True)

    # --- Main answer ---
    st.markdown("### 💬 Agent Response")
    st.markdown(f"""
    <div class='pg-card pg-card-blue' style='white-space:pre-wrap; font-size:0.9rem;'>
    {result.get("answer", "No response")}
    </div>
    """, unsafe_allow_html=True)

    # --- Root causes ---
    if result.get("root_causes"):
        st.markdown("### 🧠 Root Cause Analysis")
        for rc in result["root_causes"]:
            st.markdown(f"""
            <div class='pg-card pg-card-red' style='white-space:pre-wrap; font-size:0.85rem;'>
            {rc[:2000]}
            </div>
            """, unsafe_allow_html=True)

    # --- Recommendations ---
    if result.get("recommendations"):
        st.markdown("### 💡 Recommendations")
        recs = result["recommendations"]
        for r in recs[:8]:
            if r.strip():
                st.markdown(f"<div class='pg-card' style='padding:0.5rem 1rem;'>✅ {r}</div>",
                            unsafe_allow_html=True)

    # --- Full report ---
    if result.get("report"):
        with st.expander("📋 Full Formal Report", expanded=False):
            st.markdown(result["report"])
            st.download_button(
                "⬇️ Download Report",
                data=result["report"],
                file_name="regression_report.md",
                mime="text/markdown"
            )
