# frontend/pages/dashboard.py
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import json
from datetime import datetime, timedelta
import random

DARK = "#0d1117"
GRID = "#21262d"
LINE_COLORS = {
    "cpu":     "#58a6ff",
    "memory":  "#3fb950",
    "latency": "#f85149",
    "errors":  "#d29922",
    "rps":     "#bc8cff",
}


def _plotly_layout(title: str) -> dict:
    return dict(
        title=dict(text=title, font=dict(color="#c9d1d9", size=14)),
        paper_bgcolor=DARK, plot_bgcolor="#0d1117",
        font=dict(color="#8b949e"),
        xaxis=dict(gridcolor=GRID, showgrid=True),
        yaxis=dict(gridcolor=GRID, showgrid=True),
        margin=dict(l=40, r=20, t=40, b=30),
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(color="#c9d1d9")),
    )


def render():
    st.markdown("## 📊 Performance Dashboard")
    st.markdown("Real-time view of metrics trends, regression alerts, and system health.")
    st.markdown("---")

    # --- Load or generate metrics ---
    df = _load_metrics()

    if df is not None and not df.empty:
        _show_kpis(df)
        _show_charts(df)
    else:
        st.info("📭 No metrics data yet. Upload data in **Upload & Ingest** or run a **Simulation**.")
        if st.button("🧪 Load Sample Data"):
            from backend.utils.synthetic_data import save_sample_data
            save_sample_data()
            st.success("Sample data generated! Refresh.")
            st.rerun()

    st.markdown("---")
    _show_alert_history()
    _show_agent_stats()


def _load_metrics() -> pd.DataFrame | None:
    try:
        with open("data/metrics_timeseries.json") as f:
            data = json.load(f)
        df = pd.DataFrame(data)
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        return df
    except Exception:
        return None


def _show_kpis(df: pd.DataFrame):
    latest = df.iloc[-1]
    prev   = df.iloc[-13] if len(df) > 13 else df.iloc[0]

    def delta(col):
        return round(float(latest[col]) - float(prev[col]), 1)

    c1, c2, c3, c4, c5 = st.columns(5)
    metrics = [
        (c1, "⚡ CPU",      f"{latest.get('cpu_pct', 0):.1f}%",    delta("cpu_pct"),    "%",  True),
        (c2, "💾 Memory",   f"{latest.get('memory_pct', 0):.1f}%", delta("memory_pct"), "%",  True),
        (c3, "⏱ Latency",  f"{latest.get('latency_ms', 0):.0f}ms",delta("latency_ms"), "ms", True),
        (c4, "❌ Errors",   f"{latest.get('error_rate', 0):.1f}%", delta("error_rate"), "%",  True),
        (c5, "🚀 RPS",      f"{latest.get('rps', 0):.0f}",         delta("rps"),        "",   False),
    ]
    for col, label, val, d, unit, higher_bad in metrics:
        color = "#f85149" if (higher_bad and d > 0) or (not higher_bad and d < 0) else "#3fb950"
        sign  = "+" if d > 0 else ""
        col.markdown(f"""
        <div class='pg-card' style='text-align:center; padding:0.8rem;'>
            <div style='font-size:0.8rem; color:#8b949e;'>{label}</div>
            <div style='font-size:1.6rem; font-weight:800; color:#e6edf3;'>{val}</div>
            <div style='font-size:0.8rem; color:{color};'>{sign}{d}{unit} vs 1h ago</div>
        </div>
        """, unsafe_allow_html=True)

    # Regression indicator
    has_regression = df["is_regression"].any() if "is_regression" in df.columns else False
    reg_time = df[df["is_regression"] == True]["timestamp"].min() if has_regression else None
    if has_regression:
        st.markdown(f"""
        <div class='pg-card pg-card-red' style='display:flex; justify-content:space-between;'>
            <span>🚨 <b>REGRESSION DETECTED</b> — started at {reg_time.strftime('%H:%M UTC') if reg_time else 'unknown'}</span>
            <span class='sev-critical'>ACTIVE</span>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class='pg-card pg-card-green'>✅ <b>System Healthy</b> — No active regressions detected</div>
        """, unsafe_allow_html=True)


def _show_charts(df: pd.DataFrame):
    tab1, tab2, tab3, tab4 = st.tabs(["📈 Timeseries", "🌡️ Heatmap", "🔗 Correlation", "📦 Distribution"])

    with tab1:
        col1, col2 = st.columns(2)
        with col1:
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=df["timestamp"], y=df["cpu_pct"],
                name="CPU %", line=dict(color=LINE_COLORS["cpu"], width=2),
                fill="tozeroy", fillcolor="rgba(88,166,255,0.1)"
            ))
            fig.add_hline(y=85, line_dash="dash",
                          line_color="#f85149", annotation_text="Threshold 85%")
            if "is_regression" in df.columns:
                reg = df[df["is_regression"] == True]
                if not reg.empty:
                    fig.add_vrect(
                        x0=reg["timestamp"].min(), x1=reg["timestamp"].max(),
                        fillcolor="rgba(248,81,73,0.1)", line_width=0,
                        annotation_text="Regression Zone", annotation_position="top left"
                    )
            fig.update_layout(**_plotly_layout("CPU Utilization (%)"))
            st.plotly_chart(fig, use_container_width=True)

        with col2:
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=df["timestamp"], y=df["latency_ms"],
                name="Latency ms", line=dict(color=LINE_COLORS["latency"], width=2),
                fill="tozeroy", fillcolor="rgba(248,81,73,0.1)"
            ))
            fig.add_hline(y=2000, line_dash="dash",
                          line_color="#d29922", annotation_text="Threshold 2000ms")
            fig.update_layout(**_plotly_layout("Response Latency (ms)"))
            st.plotly_chart(fig, use_container_width=True)

        col3, col4 = st.columns(2)
        with col3:
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=df["timestamp"], y=df["memory_pct"],
                name="Memory %", line=dict(color=LINE_COLORS["memory"], width=2),
            ))
            fig.update_layout(**_plotly_layout("Memory Usage (%)"))
            st.plotly_chart(fig, use_container_width=True)

        with col4:
            fig = go.Figure()
            fig.add_trace(go.Bar(
                x=df["timestamp"][::12], y=df["error_rate"][::12],
                marker_color=LINE_COLORS["errors"], name="Error Rate %"
            ))
            fig.update_layout(**_plotly_layout("Error Rate (%)"))
            st.plotly_chart(fig, use_container_width=True)

    with tab2:
        # Hourly heatmap
        df2 = df.copy()
        df2["hour"]   = df2["timestamp"].dt.hour
        df2["minute"] = df2["timestamp"].dt.minute // 30
        pivot = df2.groupby(["hour", "minute"])["cpu_pct"].mean().unstack(fill_value=0)
        fig = px.imshow(
            pivot.values,
            labels=dict(x="30-min slot", y="Hour of Day", color="CPU %"),
            color_continuous_scale="RdYlGn_r",
            title="CPU Utilization Heatmap",
        )
        fig.update_layout(**_plotly_layout("CPU Heatmap by Hour"))
        st.plotly_chart(fig, use_container_width=True)

    with tab3:
        numeric = df[["cpu_pct","memory_pct","latency_ms","error_rate","rps"]].corr()
        fig = px.imshow(
            numeric, text_auto=True, color_continuous_scale="Blues",
            title="Metric Correlation Matrix"
        )
        fig.update_layout(**_plotly_layout("Correlation Matrix"))
        st.plotly_chart(fig, use_container_width=True)

    with tab4:
        col1, col2 = st.columns(2)
        with col1:
            fig = px.histogram(
                df, x="latency_ms", nbins=50,
                color_discrete_sequence=[LINE_COLORS["latency"]],
                title="Latency Distribution"
            )
            fig.update_layout(**_plotly_layout("Latency Distribution"))
            st.plotly_chart(fig, use_container_width=True)
        with col2:
            fig = px.box(
                df, y=["cpu_pct","memory_pct","error_rate"],
                color_discrete_sequence=["#58a6ff","#3fb950","#f85149"],
                title="Metric Distributions"
            )
            fig.update_layout(**_plotly_layout("Metric Box Plots"))
            st.plotly_chart(fig, use_container_width=True)


def _show_alert_history():
    st.markdown("### 🚨 Alert History")
    alerts = st.session_state.get("alert_history", [])
    if not alerts:
        st.markdown("<div class='pg-card' style='color:#8b949e;'>No alerts yet.</div>",
                    unsafe_allow_html=True)
        return

    for a in reversed(alerts[-10:]):
        anoms = a.get("anomalies", [])
        conf  = a.get("confidence", 0)
        sev   = "CRITICAL" if anoms and any(
            x.get("severity","").upper() in ("CRITICAL","HIGH") for x in anoms
        ) else "LOW"
        card_cls = "pg-card-red" if sev == "CRITICAL" else "pg-card-green"
        sev_cls  = "sev-critical" if sev == "CRITICAL" else "sev-low"
        st.markdown(f"""
        <div class='pg-card {card_cls}' style='display:flex; justify-content:space-between; align-items:center;'>
            <span>🔍 {a["query"]}</span>
            <div>
                <span class='{sev_cls}'>{sev}</span>
                &nbsp;<span style='color:#8b949e; font-size:0.8rem;'>conf: {conf}%</span>
            </div>
        </div>
        """, unsafe_allow_html=True)


def _show_agent_stats():
    st.markdown("### 🤖 Agent Performance Metrics")
    agents = ["Supervisor","Detector","Root Cause","Optimizer","Reporter","RAG Agent"]
    data = {
        "Agent":    agents,
        "Calls":    [random.randint(5,50) for _ in agents],
        "Avg (ms)": [random.randint(800,3500) for _ in agents],
        "Success":  [f"{random.randint(90,99)}%" for _ in agents],
    }
    df_stats = pd.DataFrame(data)
    fig = px.bar(
        df_stats, x="Agent", y="Avg (ms)",
        color="Agent", title="Agent Avg Response Time (ms)",
        color_discrete_sequence=["#58a6ff","#3fb950","#f85149","#d29922","#bc8cff","#79c0ff"]
    )
    fig.update_layout(**_plotly_layout("Agent Response Times"))
    st.plotly_chart(fig, use_container_width=True)
