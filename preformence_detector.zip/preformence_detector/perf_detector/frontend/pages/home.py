# frontend/pages/home.py
import streamlit as st

def render():
    st.markdown("""
    <h1 style='text-align:center; font-size:2.8rem;'>🛡️ PerfGuard AI</h1>
    <p style='text-align:center; font-size:1.15rem; color:#8b949e; margin-bottom:2rem;'>
        AI-powered Application Performance Regression Detector with Root Cause Insights
    </p>
    """, unsafe_allow_html=True)

    # Stats row
    c1, c2, c3, c4 = st.columns(4)
    for col, icon, val, label, color in [
        (c1, "⚡", "< 30s",  "Detection Time",    "#3fb950"),
        (c2, "🎯", "94.2%",  "Detection Accuracy", "#58a6ff"),
        (c3, "🤖", "5",      "Specialized Agents", "#d29922"),
        (c4, "📉", "68%",    "Time Saved vs Manual","#f78166"),
    ]:
        col.markdown(f"""
        <div class='pg-card' style='text-align:center;'>
            <div style='font-size:2rem;'>{icon}</div>
            <div style='font-size:1.8rem; font-weight:800; color:{color};'>{val}</div>
            <div style='font-size:0.8rem; color:#8b949e;'>{label}</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Two-column overview
    left, right = st.columns(2)
    with left:
        st.markdown("""
        <div class='pg-card pg-card-blue'>
            <h3>🧠 Multi-Agent Architecture</h3>
            <ul style='color:#c9d1d9;'>
                <li><b>Supervisor Agent</b> — intelligent query routing</li>
                <li><b>Detector Agent</b> — anomaly detection in metrics/logs</li>
                <li><b>Root Cause Agent</b> — deep reasoning with DeepSeek-R1</li>
                <li><b>Optimizer Agent</b> — ranked remediation steps</li>
                <li><b>Reporter Agent</b> — formal incident reports</li>
                <li><b>RAG Agent</b> — KB-grounded Q&A with citations</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

    with right:
        st.markdown("""
        <div class='pg-card pg-card-green'>
            <h3>📦 Capabilities</h3>
            <ul style='color:#c9d1d9;'>
                <li>📄 Multimodal ingestion — PDF, CSV, JSON, logs, images, ODS</li>
                <li>🔍 Semantic retrieval with confidence scoring (logprobs)</li>
                <li>🧹 Auto data cleaning & normalization pipeline</li>
                <li>📊 Real-time metrics dashboard with trend charts</li>
                <li>🧪 Regression scenario simulation</li>
                <li>📈 Built-in evaluation — ROUGE, grounding, faithfulness</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

    # Pipeline diagram
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("### 🔄 System Pipeline", unsafe_allow_html=False)
    steps = [
        ("📤", "Upload Data", "PDF/CSV/Logs/Images"),
        ("🧹", "Clean & Chunk", "Normalize + Split"),
        ("🧬", "Embed", "ChromaDB Storage"),
        ("🔍", "Retrieve", "Semantic Search"),
        ("🤖", "Agent Graph", "LangGraph Routing"),
        ("💡", "Insights", "RCA + Recommendations"),
    ]
    cols = st.columns(len(steps))
    for col, (icon, title, sub) in zip(cols, steps):
        col.markdown(f"""
        <div style='text-align:center; padding:0.8rem; background:#161b22;
                    border-radius:10px; border:1px solid #30363d;'>
            <div style='font-size:1.8rem;'>{icon}</div>
            <div style='font-weight:700; color:#79c0ff; font-size:0.85rem;'>{title}</div>
            <div style='font-size:0.7rem; color:#8b949e;'>{sub}</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("""
    <br>
    <div class='pg-card pg-card-yellow'>
        <b>🚀 Quick Start:</b> Go to <b>Upload &amp; Ingest</b> to load your performance data, 
        then use <b>Analyze &amp; Detect</b> or the <b>AI Assistant</b> to get insights.
        Try <b>Simulation</b> for a live demo without any data upload.
    </div>
    """, unsafe_allow_html=True)
