from backend.rag.retriever import retrieve_similar_incidents

query = """
High latency spike.
Database timeout errors.
Connection pool exhausted.
"""

docs = retrieve_similar_incidents(query)

print("\n===== RETRIEVED INCIDENTS =====\n")

for i, doc in enumerate(docs):

    print(f"\nResult {i+1}")
    print(doc.page_content)