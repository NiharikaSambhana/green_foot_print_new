from backend.agents.log_analyzer import (
    log_analyzer_agent
)

state = {}

result = log_analyzer_agent(state)

print(result["parsed_logs"])