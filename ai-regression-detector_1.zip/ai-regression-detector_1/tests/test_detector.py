from backend.agents.regression_detector import (
    regression_detector_agent
)

state = {}

result = regression_detector_agent(state)

print("\n===== DETECTOR OUTPUT =====\n")

print("Severity:")
print(result["severity"])

print("\nSeverity Score:")
print(result["severity_score"])

print("\nRegression %:")
print(result["regression_percent"])

print("\nAnomalies:")
print(result["anomalies"])