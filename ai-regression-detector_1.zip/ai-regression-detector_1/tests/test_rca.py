from backend.agents.root_cause_agent import (
    root_cause_agent
)

state = {
    "anomalies": [
        {
            "cpu": 95,
            "latency": 3000
        }
    ],
    "parsed_logs": [
        "ERROR Database timeout occurred",
        "ERROR Connection pool exhausted"
    ],
    "retrieved_incidents": [
        "Previous DB pool exhaustion incident"
    ]
}

result = root_cause_agent(state)

print(result["root_cause"])