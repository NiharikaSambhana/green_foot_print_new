def recommendation_agent(state):

    recommendations = [
        "Increase DB connection pool",
        "Check slow SQL queries",
        "Scale application horizontally",
        "Enable caching",
        "Rollback recent deployment"
    ]

    state["recommendations"] = recommendations

    return state