from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0
)


def root_cause_agent(state):

    print("🧠 Running Root Cause Agent")

    prompt = f"""
    You are an expert Site Reliability Engineer.

    Analyze:
    1. Performance regression metrics
    2. Application logs
    3. Historical incidents

    Generate:
    - probable root cause
    - severity explanation
    - impacted systems
    - remediation steps

    Regression Summary:
    Severity: {state['severity']}
    Severity Score: {state['severity_score']}
    Regression Percentage:
    {state['regression_percent']}%

    Performance Anomalies:
    {state['anomalies']}

    Logs:
    {state['parsed_logs']}

    Historical Incidents:
    {state['retrieved_incidents']}
    """

    response = llm.invoke([
        HumanMessage(content=prompt)
    ])

    state["root_cause"] = response.content

    return state