def log_analyzer_agent(state):

    with open(
        "data/sample_logs/logs.txt",
        "r",
        encoding="utf-8"
    ) as f:

        logs = f.readlines()

    important_logs = []

    keywords = [
        "ERROR",
        "timeout",
        "memory",
        "connection",
        "pool",
        "latency"
    ]

    for line in logs:

        for keyword in keywords:

            if keyword.lower() in line.lower():
                important_logs.append(line.strip())

    state["parsed_logs"] = important_logs

    return state