from rag.retriever import retrieve_similar_incidents


def rag_agent(state):

    query = f"""
    Anomalies:
    {state['anomalies']}

    Logs:
    {state['parsed_logs']}
    """

    docs = retrieve_similar_incidents(query)

    retrieved = []

    for d in docs:
        retrieved.append(d.page_content)

    state["retrieved_incidents"] = retrieved

    return state