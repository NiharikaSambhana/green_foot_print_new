from langgraph.graph import StateGraph, END

from agents.state import AgentState

from agents.regression_detector import (
    regression_detector_agent
)

from agents.log_analyzer import (
    log_analyzer_agent
)

from agents.rag_agent import rag_agent

from agents.root_cause_agent import (
    root_cause_agent
)

from agents.recommendation_agent import (
    recommendation_agent
)

from agents.report_agent import (
    report_agent
)

workflow = StateGraph(AgentState)

workflow.add_node(
    "regression_detector",
    regression_detector_agent
)

workflow.add_node(
    "log_analyzer",
    log_analyzer_agent
)

workflow.add_node(
    "rag_agent",
    rag_agent
)

workflow.add_node(
    "root_cause_agent",
    root_cause_agent
)

workflow.add_node(
    "recommendation_agent",
    recommendation_agent
)

workflow.add_node(
    "report_agent",
    report_agent
)

workflow.set_entry_point(
    "regression_detector"
)

workflow.add_edge(
    "regression_detector",
    "log_analyzer"
)

workflow.add_edge(
    "log_analyzer",
    "rag_agent"
)

workflow.add_edge(
    "rag_agent",
    "root_cause_agent"
)

workflow.add_edge(
    "root_cause_agent",
    "recommendation_agent"
)

workflow.add_edge(
    "recommendation_agent",
    "report_agent"
)

workflow.add_edge(
    "report_agent",
    END
)

graph = workflow.compile()