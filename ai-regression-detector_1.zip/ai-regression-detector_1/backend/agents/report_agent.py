def report_agent(state):

    print("📊 Running Report Agent")

    report = f"""
========================================
AI PERFORMANCE RCA REPORT
========================================

SEVERITY:
{state['severity']}

SEVERITY SCORE:
{state['severity_score']}

REGRESSION PERCENTAGE:
{state['regression_percent']}%

========================================

ANOMALY SUMMARY:
"""

    for anomaly in state["anomalies"]:

        report += f"""

Metric: {anomaly['metric']}
Baseline: {anomaly['baseline']}
Current: {anomaly['current']}
Regression: {anomaly['regression_percent']}%
"""

    report += f"""

========================================
ROOT CAUSE ANALYSIS
========================================

{state['root_cause']}

========================================
RECOMMENDATIONS
========================================
"""

    for r in state["recommendations"]:
        report += f"\n✅ {r}"

    report += "\n\n========================================"

    state["final_report"] = report

    return state