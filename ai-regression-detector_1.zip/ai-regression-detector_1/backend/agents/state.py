from typing import TypedDict, List


class AgentState(TypedDict):

    metrics_summary: str

    parsed_logs: List[str]

    anomalies: List[dict]

    retrieved_incidents: List[str]

    root_cause: str

    recommendations: List[str]

    final_report: str

    severity: str

    severity_score: int

    regression_percent: float