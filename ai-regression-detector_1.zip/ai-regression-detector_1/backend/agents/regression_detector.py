import pandas as pd

from backend.utils.severity_calculator import (
    calculate_regression_percentage,
    classify_severity,
    severity_score
)


def regression_detector_agent(state):

    print("🚨 Running Regression Detector Agent")

    df = pd.read_csv(
        "data/sample_metrics/metrics.csv"
    )

    # ==========================
    # BASELINE
    # ==========================

    baseline_latency = (
        df["latency"][:20].mean()
    )

    baseline_cpu = (
        df["cpu"][:20].mean()
    )

    baseline_memory = (
        df["memory"][:20].mean()
    )

    # ==========================
    # CURRENT WINDOW
    # ==========================

    current_latency = (
        df["latency"].tail(10).mean()
    )

    current_cpu = (
        df["cpu"].tail(10).mean()
    )

    current_memory = (
        df["memory"].tail(10).mean()
    )

    # ==========================
    # REGRESSION %
    # ==========================

    latency_regression = (
        calculate_regression_percentage(
            baseline_latency,
            current_latency
        )
    )

    cpu_regression = (
        calculate_regression_percentage(
            baseline_cpu,
            current_cpu
        )
    )

    memory_regression = (
        calculate_regression_percentage(
            baseline_memory,
            current_memory
        )
    )

    # ==========================
    # FINAL SEVERITY
    # ==========================

    max_regression = max(
        latency_regression,
        cpu_regression,
        memory_regression
    )

    severity = classify_severity(
        max_regression
    )

    sev_score = severity_score(
        severity
    )

    anomalies = [
        {
            "metric": "latency",
            "baseline": round(baseline_latency, 2),
            "current": round(current_latency, 2),
            "regression_percent": latency_regression
        },
        {
            "metric": "cpu",
            "baseline": round(baseline_cpu, 2),
            "current": round(current_cpu, 2),
            "regression_percent": cpu_regression
        },
        {
            "metric": "memory",
            "baseline": round(baseline_memory, 2),
            "current": round(current_memory, 2),
            "regression_percent": memory_regression
        }
    ]

    state["anomalies"] = anomalies

    state["severity"] = severity

    state["severity_score"] = sev_score

    state["regression_percent"] = round(
        max_regression,
        2
    )

    return state