import pandas as pd

from fastapi import FastAPI, UploadFile, File

from services.log_parser import extract_error_patterns

from agents.regression_detector import regression_detector_agent
from agents.root_cause_agent import root_cause_agent
from agents.recommendation_agent import recommendation_agent
from agents.report_agent import report_agent

app = FastAPI()

@app.post("/analyze")
async def analyze(
    metrics_file: UploadFile = File(...),
    logs_file: UploadFile = File(...)
):

    metrics_df = pd.read_csv(metrics_file.file)

    logs_text = (await logs_file.read()).decode()

    parsed_logs = extract_error_patterns(logs_text)

    state = {
        "metrics_df": metrics_df,
        "parsed_logs": parsed_logs
    }

    state = regression_detector_agent(state)

    state = root_cause_agent(state)

    state = recommendation_agent(state)

    state = report_agent(state)

    return state["report"]