def calculate_regression_percentage(
    baseline,
    current
):

    if baseline == 0:
        return 0

    regression = (
        (current - baseline)
        / baseline
    ) * 100

    return round(regression, 2)


def classify_severity(regression_percent):

    if regression_percent < 10:
        return "NORMAL"

    elif regression_percent < 30:
        return "LOW"

    elif regression_percent < 70:
        return "WARNING"

    else:
        return "CRITICAL"


def severity_score(severity):

    mapping = {
        "NORMAL": 0,
        "LOW": 1,
        "WARNING": 2,
        "CRITICAL": 3
    }

    return mapping.get(severity, 0)