from langchain.docstore.document import Document
import os


def load_documents(folder_path="data/sample_logs"):

    documents = []

    for file in os.listdir(folder_path):

        path = os.path.join(folder_path, file)

        if file.endswith(".txt"):

            with open(path, "r", encoding="utf-8") as f:
                content = f.read()

            documents.append(
                Document(
                    page_content=content,
                    metadata={"source": file}
                )
            )

    return documents