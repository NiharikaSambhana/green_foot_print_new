from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

from rag.document_loader import load_documents
from rag.datacleaner import clean_documents


def ingest_documents():

    docs = load_documents()

    docs = clean_documents(docs)

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=50
    )

    split_docs = splitter.split_documents(docs)

    embeddings = OpenAIEmbeddings()

    vectordb = FAISS.from_documents(
        split_docs,
        embeddings
    )

    vectordb.save_local("vectordb")

    print("✅ Vector DB created successfully")


if __name__ == "__main__":
    ingest_documents()