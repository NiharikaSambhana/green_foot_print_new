from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS


def retrieve_similar_incidents(query, k=3):

    db = FAISS.load_local(
        "vectordb",
        OpenAIEmbeddings(),
        allow_dangerous_deserialization=True
    )

    docs = db.similarity_search(query, k=k)

    return docs