import re


def clean_text(text):

    # Remove IP addresses
    text = re.sub(
        r"\b\d{1,3}(?:\.\d{1,3}){3}\b",
        "[IP]",
        text
    )

    # Remove timestamps
    text = re.sub(
        r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}",
        "[TIMESTAMP]",
        text
    )

    # Remove extra spaces
    text = re.sub(r"\s+", " ", text)

    return text.strip()


def clean_documents(documents):

    for doc in documents:
        doc.page_content = clean_text(doc.page_content)

    return documents