from backend.agents.graph import graph


def run_pipeline():

    state = {
        "metrics_summary": "",
        "parsed_logs": [],
        "anomalies": [],
        "retrieved_incidents": [],
        "root_cause": "",
        "recommendations": [],
        "final_report": "",
        "severity": "",
        "severity_score": 0,
        "regression_percent": 0
    }

    result = graph.invoke(state)

    print(result["final_report"])


if __name__ == "__main__":
    run_pipeline()